// @title 管理后台
import {useState, useCallback, useEffect} from 'react'
import Taro, {useDidShow} from '@tarojs/taro'
import {useAuth} from '@/contexts/AuthContext'
import {supabase} from '@/client/supabase'
import {getSurveyCycles, getActiveCycle, getSurveyStats} from '@/db/api'

export default function Admin() {
  const {user, profile, loading} = useAuth()
  const [cycles, setCycles] = useState<{id: string; name: string; status: string}[]>([])
  const [stats, setStats] = useState<{
    totalEvaluatees: number
    totalSubmissions: number
    completionRate: number
    dimensionStats: {dimension: string; avg: number; count: number}[]
    departmentStats: {department: string; count: number; avg: number}[]
    identityStats: {identity: string; count: number; avg: number}[]
  } | null>(null)
  const [selectedCycle, setSelectedCycle] = useState<string>('')

  const isAdmin = profile?.role === 'admin' || profile?.role === 'super_admin'

  const loadData = useCallback(async () => {
    if (!user || !isAdmin) return
    try {
      const allCycles = await getSurveyCycles()
      setCycles(allCycles)
      const active = allCycles.find((c) => c.status === 'active')
      if (active) {
        setSelectedCycle(active.id)
        const s = await getSurveyStats(active.id)
        setStats(s)
      }
    } catch (e) {
      console.error('加载失败:', e)
    }
  }, [user, isAdmin])

  useEffect(() => {
    loadData()
  }, [loadData])

  useDidShow(() => {
    loadData()
  })

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="i-mdi-loading text-4xl text-primary animate-spin" />
      </div>
    )
  }

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center px-6">
        <div className="i-mdi-lock-outline text-6xl text-muted-foreground mb-4" />
        <span className="text-xl text-muted-foreground">无权限访问管理后台</span>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background pb-8">
      {/* 顶部 */}
      <div className="bg-gradient-primary px-6 pt-8 pb-10 rounded-b-3xl">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center">
            <div className="i-mdi-shield-account text-3xl text-white" />
          </div>
          <div className="flex flex-col flex-1">
            <span className="text-2xl font-bold text-white">管理后台</span>
            <span className="text-xl text-white/80">
              {profile?.role === 'super_admin' ? '超级管理员' : '管理员'}
            </span>
          </div>
          <button
            type="button"
            onClick={async () => {
              Taro.showModal({
                title: '退出登录',
                content: '确认退出管理员账号？',
                success: async (res) => {
                  if (res.confirm) {
                    await supabase.auth.signOut()
                    Taro.reLaunch({url: '/pages/admin-login/index'})
                  }
                },
              })
            }}
            className="flex items-center justify-center leading-none break-keep rounded-lg bg-white/20">
            <div className="py-2 px-3 flex items-center gap-1">
              <div className="i-mdi-logout text-xl text-white" />
              <span className="text-xl text-white">退出</span>
            </div>
          </button>
        </div>
      </div>

      {/* 功能入口 */}
      <div className="px-4 -mt-4">
        <div className="bg-card rounded-2xl shadow-card p-4">
          <div className="flex flex-row gap-3">
            <div
              onClick={() => Taro.navigateTo({url: '/pages/admin-data/index'})}
              className="flex-1 flex flex-col items-center bg-muted rounded-xl py-4">
              <div className="i-mdi-database-outline text-3xl text-primary mb-2" />
              <span className="text-xl text-foreground">原始数据</span>
            </div>
            <div
              onClick={() => Taro.navigateTo({url: '/pages/admin-survey/index'})}
              className="flex-1 flex flex-col items-center bg-muted rounded-xl py-4">
              <div className="i-mdi-clipboard-edit-outline text-3xl text-accent mb-2" />
              <span className="text-xl text-foreground">问卷管理</span>
            </div>
            {profile?.role === 'super_admin' && (
              <div
                onClick={() => Taro.navigateTo({url: '/pages/admin-users/index'})}
                className="flex-1 flex flex-col items-center bg-muted rounded-xl py-4">
                <div className="i-mdi-account-group-outline text-3xl text-destructive mb-2" />
                <span className="text-xl text-foreground">用户管理</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* 数据总览 */}
      {stats && (
        <div className="px-4 mt-4">
          <div className="flex items-center gap-2 mb-3">
            <div className="i-mdi-chart-bar text-2xl text-primary" />
            <span className="text-2xl font-bold text-foreground">数据总览</span>
          </div>

          {/* 核心指标 */}
          <div className="bg-card rounded-2xl shadow-card p-4 mb-3">
            <div className="flex flex-row gap-3">
              <div className="flex-1 flex flex-col items-center bg-muted rounded-xl py-3">
                <span className="text-2xl font-bold text-primary">{stats.totalEvaluatees}</span>
                <span className="text-xl text-muted-foreground">被评价人</span>
              </div>
              <div className="flex-1 flex flex-col items-center bg-muted rounded-xl py-3">
                <span className="text-2xl font-bold text-accent">{stats.totalSubmissions}</span>
                <span className="text-xl text-muted-foreground">已提交</span>
              </div>
              <div className="flex-1 flex flex-col items-center bg-muted rounded-xl py-3">
                <span className="text-2xl font-bold text-success">{stats.completionRate}%</span>
                <span className="text-xl text-muted-foreground">完成率</span>
              </div>
            </div>
          </div>

          {/* 各维度平均分 */}
          <div className="bg-card rounded-2xl shadow-card p-4 mb-3">
            <span className="text-xl font-bold text-foreground mb-3">各维度平均分</span>
            <div className="flex flex-col gap-3">
              {stats.dimensionStats.map((d) => (
                <div key={d.dimension} className="flex items-center gap-3">
                  <span className="text-xl text-foreground w-20">{d.dimension}</span>
                  <div className="flex-1 h-3 bg-muted rounded-full overflow-hidden">
                    <div
                      className="h-full bg-primary rounded-full"
                      style={{width: `${d.avg * 10}%`}}
                    />
                  </div>
                  <span className="text-xl font-bold text-primary w-10 text-right">{d.avg}</span>
                </div>
              ))}
            </div>
          </div>

          {/* 科室对比 */}
          <div className="bg-card rounded-2xl shadow-card p-4 mb-3">
            <span className="text-xl font-bold text-foreground mb-3">科室对比</span>
            <div className="flex flex-col gap-3">
              {stats.departmentStats.map((d) => (
                <div key={d.department} className="flex items-center gap-3">
                  <span className="text-xl text-foreground flex-1">{d.department}</span>
                  <span className="text-xl text-muted-foreground">{d.count}人</span>
                  <span className="text-xl font-bold text-accent w-10 text-right">{d.avg}</span>
                </div>
              ))}
            </div>
          </div>

          {/* 身份对比 */}
          <div className="bg-card rounded-2xl shadow-card p-4">
            <span className="text-xl font-bold text-foreground mb-3">身份对比</span>
            <div className="flex flex-col gap-3">
              {stats.identityStats.map((d) => (
                <div key={d.identity} className="flex items-center gap-3">
                  <span className="text-xl text-foreground flex-1">{d.identity}</span>
                  <span className="text-xl text-muted-foreground">{d.count}人</span>
                  <span className="text-xl font-bold text-primary w-10 text-right">{d.avg}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 问卷列表 */}
      <div className="px-4 mt-4">
        <div className="flex items-center gap-2 mb-3">
          <div className="i-mdi-format-list-bulleted text-2xl text-primary" />
          <span className="text-2xl font-bold text-foreground">问卷周期</span>
        </div>
        <div className="bg-card rounded-2xl shadow-card overflow-hidden">
          {cycles.length === 0 ? (
            <div className="flex flex-col items-center py-8">
              <div className="i-mdi-inbox-outline text-4xl text-muted-foreground mb-2" />
              <span className="text-xl text-muted-foreground">暂无问卷</span>
            </div>
          ) : (
            cycles.map((c, idx) => (
              <div
                key={c.id}
                className={`flex items-center justify-between px-5 py-4 ${
                  idx < cycles.length - 1 ? 'border-b border-border' : ''
                }`}>
                <div className="flex flex-col">
                  <span className="text-xl font-bold text-foreground">{c.name}</span>
                  <span className="text-xl text-muted-foreground">
                    {c.status === 'active' ? '进行中' : c.status === 'draft' ? '未开始' : '已结束'}
                  </span>
                </div>
                <div className="i-mdi-chevron-right text-2xl text-muted-foreground" />
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  )
}