export default definePageConfig({
  navigationBarTitleText: '管理员登录',
  enableShareAppMessage: true,
  enableShareTimeline: true,
})
