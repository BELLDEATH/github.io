// @title 管理员登录
import {useState} from 'react'
import Taro from '@tarojs/taro'
import {useAuth} from '@/contexts/AuthContext'

export default function AdminLogin() {
  const {signInWithUsername} = useAuth()
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)

  const handleLogin = async () => {
    if (!username.trim() || !password.trim()) {
      Taro.showToast({title: '请输入账号和密码', icon: 'none'})
      return
    }
    setLoading(true)
    const {error} = await signInWithUsername(username.trim(), password)
    setLoading(false)
    if (error) {
      Taro.showToast({title: '账号或密码错误', icon: 'none'})
      return
    }
    Taro.switchTab({url: '/pages/home/index'})
  }

  return (
    <div className="min-h-screen bg-gradient-subtle flex flex-col px-6">
      {/* 品牌区 */}
      <div className="flex flex-col items-center pt-20 pb-10">
        <div className="w-20 h-20 rounded-2xl bg-gradient-primary flex items-center justify-center shadow-elegant mb-5">
          <div className="i-mdi-shield-account text-4xl text-white" />
        </div>
        <h1 className="text-3xl font-bold text-foreground">管理员控制台</h1>
        <p className="text-xl text-muted-foreground mt-2">员工互评系统后台管理</p>
      </div>

      {/* 登录表单 */}
      <div className="bg-card rounded-2xl shadow-card p-6">
        <div className="flex items-center gap-2 mb-6">
          <div className="i-mdi-lock-outline text-2xl text-primary" />
          <span className="text-2xl font-bold text-foreground">管理员登录</span>
        </div>

        <div className="flex flex-col gap-4">
          {/* 账号输入 */}
          <div className="flex flex-col gap-1">
            <span className="text-xl text-muted-foreground ml-1">管理员账号</span>
            <div className="border-2 border-input rounded-xl px-4 py-3 bg-background overflow-hidden">
              <input
                className="w-full text-xl text-foreground bg-transparent outline-none"
                placeholder="请输入管理员账号"
                value={username}
                onInput={(e) => {
                  const ev = e as any
                  setUsername(ev.detail?.value ?? ev.target?.value ?? '')
                }}
              />
            </div>
          </div>

          {/* 密码输入 */}
          <div className="flex flex-col gap-1">
            <span className="text-xl text-muted-foreground ml-1">登录密码</span>
            <div className="border-2 border-input rounded-xl px-4 py-3 bg-background overflow-hidden">
              <input
                className="w-full text-xl text-foreground bg-transparent outline-none"
                placeholder="请输入密码"
                type="password"
                value={password}
                onInput={(e) => {
                  const ev = e as any
                  setPassword(ev.detail?.value ?? ev.target?.value ?? '')
                }}
              />
            </div>
          </div>

          {/* 登录按钮 */}
          <button
            type="button"
            onClick={handleLogin}
            className={`w-full flex items-center justify-center leading-none break-keep rounded-xl mt-2 ${
              loading ? 'bg-primary/50' : 'bg-primary'
            }`}>
            <div className="py-4 px-6 flex items-center gap-2">
              <div className="i-mdi-login text-2xl text-white" />
              <span className="text-xl text-primary-foreground font-semibold">
                {loading ? '登录中...' : '立即登录'}
              </span>
            </div>
          </button>
        </div>

        {/* 提示信息 */}
        <div className="mt-5 bg-muted/60 rounded-xl px-4 py-3">
          <div className="flex items-start gap-2">
            <div className="i-mdi-information-outline text-xl text-accent mt-0.5" />
            <span className="text-xl text-muted-foreground leading-relaxed flex-1">
              管理员账号由系统统一分配，如需获取请联系超级管理员
            </span>
          </div>
        </div>
      </div>

      {/* 返回普通登录 */}
      <div className="flex items-center justify-center mt-6 gap-2">
        <div className="i-mdi-arrow-left text-xl text-muted-foreground" />
        <span
          className="text-xl text-primary"
          onClick={() => Taro.navigateBack()}>
          返回员工登录
        </span>
      </div>
    </div>
  )
}
