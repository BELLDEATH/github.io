// @title 首页
import {useState, useCallback, useEffect} from 'react'
import Taro, {useDidShow} from '@tarojs/taro'
import {useAuth} from '@/contexts/AuthContext'
import {getActiveCycle, getMySubmission, getEvaluatees, getDimensions} from '@/db/api'

export default function Home() {
  const {user, profile, loading} = useAuth()
  const [cycle, setCycle] = useState<{id: string; name: string; status: string} | null>(null)
  const [submitted, setSubmitted] = useState(false)
  const [evaluateeCount, setEvaluateeCount] = useState(0)
  const [dimensionCount, setDimensionCount] = useState(0)
  const [showPrivacy, setShowPrivacy] = useState(false)
  const [privacyAgreed, setPrivacyAgreed] = useState(false)

  const loadData = useCallback(async () => {
    if (!user) return
    try {
      const activeCycle = await getActiveCycle()
      setCycle(activeCycle)
      if (activeCycle) {
        const [sub, evals, dims] = await Promise.all([
          getMySubmission(activeCycle.id, user.id),
          getEvaluatees(activeCycle.id),
          getDimensions(),
        ])
        setSubmitted(!!sub)
        setEvaluateeCount(evals.length)
        setDimensionCount(dims.length)
      }
    } catch (e) {
      console.error('加载数据失败:', e)
    }
  }, [user])

  useEffect(() => {
    loadData()
  }, [loadData])

  useDidShow(() => {
    loadData()
  })

  // 首次进入隐私弹窗
  useEffect(() => {
    const agreed = Taro.getStorageSync('privacy_agreed')
    if (!agreed) {
      setShowPrivacy(true)
    }
  }, [])

  const handleAgree = () => {
    Taro.setStorageSync('privacy_agreed', '1')
    setPrivacyAgreed(true)
    setShowPrivacy(false)
  }

  const handleDisagree = () => {
    setShowPrivacy(false)
    Taro.showToast({title: '未同意隐私政策，部分功能受限', icon: 'none'})
  }

  const goSurvey = () => {
    if (!cycle || cycle.status !== 'active') {
      Taro.showToast({title: '当前无进行中的问卷', icon: 'none'})
      return
    }
    if (submitted) {
      Taro.switchTab({url: '/pages/result/index'})
      return
    }
    Taro.navigateTo({url: '/pages/identity/index'})
  }

  const goResult = () => {
    Taro.switchTab({url: '/pages/result/index'})
  }

  const isAdmin = profile?.role === 'admin' || profile?.role === 'super_admin'

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="i-mdi-loading text-4xl text-primary animate-spin" />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background pb-8">
      {/* 顶部欢迎区 */}
      <div className="bg-gradient-primary px-6 pt-10 pb-12 rounded-b-3xl">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center">
            <div className="i-mdi-account-circle text-3xl text-white" />
          </div>
          <div className="flex flex-col">
            <span className="text-2xl font-bold text-white">欢迎回来</span>
            <span className="text-xl text-white/80">匿名评价 · 保护隐私</span>
          </div>
        </div>
      </div>

      {/* 当前问卷卡片 */}
      <div className="px-4 -mt-6">
        <div className="bg-card rounded-2xl shadow-card p-5">
          <div className="flex items-center gap-2 mb-3">
            <div className="i-mdi-clipboard-text-outline text-2xl text-primary" />
            <span className="text-2xl font-bold text-foreground">当前问卷</span>
          </div>
          {cycle ? (
            <div className="flex flex-col gap-3">
              <div className="flex items-center justify-between">
                <span className="text-xl text-foreground font-semibold">{cycle.name}</span>
                <div
                  className={`px-3 py-1 rounded-full ${
                    cycle.status === 'active'
                      ? 'bg-success/10'
                      : cycle.status === 'draft'
                        ? 'bg-muted'
                        : 'bg-destructive/10'
                  }`}>
                  <span
                    className={`text-xl ${
                      cycle.status === 'active'
                        ? 'text-success'
                        : cycle.status === 'draft'
                          ? 'text-muted-foreground'
                          : 'text-destructive'
                    }`}>
                    {cycle.status === 'active' ? '进行中' : cycle.status === 'draft' ? '未开始' : '已结束'}
                  </span>
                </div>
              </div>
              <div className="flex flex-row gap-4">
                <div className="flex-1 bg-muted rounded-xl p-3 flex flex-col items-center">
                  <span className="text-2xl font-bold text-primary">{evaluateeCount}</span>
                  <span className="text-xl text-muted-foreground">被评价人</span>
                </div>
                <div className="flex-1 bg-muted rounded-xl p-3 flex flex-col items-center">
                  <span className="text-2xl font-bold text-accent">{dimensionCount}</span>
                  <span className="text-xl text-muted-foreground">评价维度</span>
                </div>
              </div>
              {submitted ? (
                <button
                  type="button"
                  onClick={goResult}
                  className="w-full flex items-center justify-center leading-none break-keep rounded-xl bg-success">
                  <div className="py-4 px-6 flex items-center gap-2">
                    <div className="i-mdi-check-circle-outline text-2xl text-white" />
                    <span className="text-xl text-white font-semibold">已完成 · 查看结果</span>
                  </div>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={goSurvey}
                  className={`w-full flex items-center justify-center leading-none break-keep rounded-xl ${
                    cycle.status === 'active' ? 'bg-primary' : 'bg-muted'
                  }`}>
                  <div className="py-4 px-6 flex items-center gap-2">
                    <div className="i-mdi-pencil-outline text-2xl text-white" />
                    <span className={`text-xl font-semibold ${cycle.status === 'active' ? 'text-white' : 'text-muted-foreground'}`}>
                      {cycle.status === 'active' ? '开始评价' : '暂不可用'}
                    </span>
                  </div>
                </button>
              )}
            </div>
          ) : (
            <div className="flex flex-col items-center py-6">
              <div className="i-mdi-inbox-outline text-5xl text-muted-foreground mb-3" />
              <span className="text-xl text-muted-foreground">暂无进行中的问卷</span>
            </div>
          )}
        </div>
      </div>

      {/* 功能入口 */}
      <div className="px-4 mt-4">
        <div className="bg-card rounded-2xl shadow-card p-5">
          <span className="text-2xl font-bold text-foreground mb-4">快捷功能</span>
          <div className="flex flex-row gap-3">
            <div
              onClick={goResult}
              className="flex-1 flex flex-col items-center bg-muted rounded-xl py-4">
              <div className="i-mdi-chart-bar text-3xl text-primary mb-2" />
              <span className="text-xl text-foreground">查看结果</span>
            </div>
            <div
              onClick={() => Taro.switchTab({url: '/pages/profile/index'})}
              className="flex-1 flex flex-col items-center bg-muted rounded-xl py-4">
              <div className="i-mdi-account-outline text-3xl text-accent mb-2" />
              <span className="text-xl text-foreground">个人中心</span>
            </div>
            {isAdmin && (
              <div
                onClick={() => Taro.navigateTo({url: '/pages/admin/index'})}
                className="flex-1 flex flex-col items-center bg-muted rounded-xl py-4">
                <div className="i-mdi-shield-account-outline text-3xl text-destructive mb-2" />
                <span className="text-xl text-foreground">管理后台</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* 说明区 */}
      <div className="px-4 mt-4">
        <div className="bg-card rounded-2xl shadow-card p-5">
          <div className="flex items-center gap-2 mb-3">
            <div className="i-mdi-information-outline text-2xl text-primary" />
            <span className="text-2xl font-bold text-foreground">使用说明</span>
          </div>
          <div className="flex flex-col gap-3">
            <div className="flex items-start gap-2">
              <div className="i-mdi-shield-check-outline text-xl text-success mt-1" />
              <span className="text-xl text-muted-foreground leading-relaxed flex-1">
                所有评价完全匿名，前台不会显示您的任何个人信息
              </span>
            </div>
            <div className="flex items-start gap-2">
              <div className="i-mdi-format-list-numbered text-xl text-primary mt-1" />
              <span className="text-xl text-muted-foreground leading-relaxed flex-1">
                采用10分制矩阵量表，对每位同事逐项打分
              </span>
            </div>
            <div className="flex items-start gap-2">
              <div className="i-mdi-lock-outline text-xl text-accent mt-1" />
              <span className="text-xl text-muted-foreground leading-relaxed flex-1">
                每轮问卷仅可提交一次，提交后不可修改
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* 隐私政策弹窗 M01 */}
      {showPrivacy && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center px-6">
          <div className="bg-card rounded-2xl p-6 w-full max-w-sm">
            <h2 className="text-2xl font-bold text-foreground text-center mb-4">服务协议与隐私政策</h2>
            <p className="text-xl text-muted-foreground leading-relaxed mb-4">
              本系统仅用于部门内部员工互评打分。我们会收集您的微信昵称用于后台数据追溯（仅管理员可见），前台所有评价完全匿名。请点击阅读
              <span
                className="text-primary"
                onClick={() => Taro.navigateTo({url: '/pages/privacy/index'})}>
                《隐私政策》
              </span>
              了解详情。
            </p>
            <div className="flex flex-col gap-3">
              <button
                type="button"
                onClick={handleAgree}
                className="w-full flex items-center justify-center leading-none break-keep rounded-xl bg-primary">
                <div className="py-3 px-6">
                  <span className="text-xl text-primary-foreground font-semibold">同意并继续</span>
                </div>
              </button>
              <button
                type="button"
                onClick={handleDisagree}
                className="w-full flex items-center justify-center leading-none break-keep rounded-xl bg-muted">
                <div className="py-3 px-6">
                  <span className="text-xl text-muted-foreground font-semibold">不同意</span>
                </div>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}