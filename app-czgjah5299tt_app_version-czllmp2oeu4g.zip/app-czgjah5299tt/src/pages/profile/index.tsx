// @title 个人中心
import {useState, useCallback, useEffect} from 'react'
import Taro, {useDidShow} from '@tarojs/taro'
import {useAuth} from '@/contexts/AuthContext'

export default function Profile() {
  const {user, profile, signOut} = useAuth()
  const [showLogout, setShowLogout] = useState(false)

  const handleLogout = async () => {
    await signOut()
    Taro.reLaunch({url: '/pages/login/index'})
  }

  const isAdmin = profile?.role === 'admin' || profile?.role === 'super_admin'

  return (
    <div className="min-h-screen bg-background pb-8">
      {/* 用户信息 */}
      <div className="bg-gradient-primary px-6 pt-10 pb-12 rounded-b-3xl">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-full bg-white/20 flex items-center justify-center">
            <div className="i-mdi-account-circle text-4xl text-white" />
          </div>
          <div className="flex flex-col">
            <span className="text-2xl font-bold text-white">{profile?.nickname || '匿名用户'}</span>
            <div className="flex items-center gap-2 mt-1">
              <span className="text-xl text-white/80">
                {profile?.role === 'super_admin' ? '超级管理员' : profile?.role === 'admin' ? '管理员' : '普通用户'}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* 功能菜单 */}
      <div className="px-4 -mt-4">
        <div className="bg-card rounded-2xl shadow-card overflow-hidden">
          {isAdmin && (
            <div
              onClick={() => Taro.navigateTo({url: '/pages/admin/index'})}
              className="flex items-center gap-3 px-5 py-4 border-b border-border">
              <div className="i-mdi-shield-account-outline text-2xl text-destructive" />
              <span className="text-xl text-foreground flex-1">管理后台</span>
              <div className="i-mdi-chevron-right text-2xl text-muted-foreground" />
            </div>
          )}
          <div
            onClick={() => Taro.navigateTo({url: '/pages/privacy/index'})}
            className="flex items-center gap-3 px-5 py-4 border-b border-border">
            <div className="i-mdi-file-document-outline text-2xl text-primary" />
            <span className="text-xl text-foreground flex-1">隐私政策</span>
            <div className="i-mdi-chevron-right text-2xl text-muted-foreground" />
          </div>
          <div
            onClick={() => Taro.navigateTo({url: '/pages/data-list/index'})}
            className="flex items-center gap-3 px-5 py-4 border-b border-border">
            <div className="i-mdi-format-list-bulleted text-2xl text-accent" />
            <span className="text-xl text-foreground flex-1">个人信息清单</span>
            <div className="i-mdi-chevron-right text-2xl text-muted-foreground" />
          </div>
          <div
            onClick={() => setShowLogout(true)}
            className="flex items-center gap-3 px-5 py-4">
            <div className="i-mdi-logout text-2xl text-destructive" />
            <span className="text-xl text-destructive flex-1">退出登录</span>
            <div className="i-mdi-chevron-right text-2xl text-muted-foreground" />
          </div>
        </div>
      </div>

      {/* 关于 */}
      <div className="px-4 mt-4">
        <div className="bg-card rounded-2xl shadow-card p-5">
          <div className="flex items-center gap-2 mb-3">
            <div className="i-mdi-information-outline text-2xl text-primary" />
            <span className="text-2xl font-bold text-foreground">关于系统</span>
          </div>
          <p className="text-xl text-muted-foreground leading-relaxed">
            部门员工互评匿名打分系统，用于部门内部员工之间的定期互评打分，支持绩效参考与团队建设。所有评价完全匿名，保护评价者隐私。
          </p>
        </div>
      </div>

      {/* 退出确认弹窗 */}
      {showLogout && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center px-6">
          <div className="bg-card rounded-2xl p-6 w-full max-w-sm">
            <h2 className="text-2xl font-bold text-foreground text-center mb-3">确认退出</h2>
            <p className="text-xl text-muted-foreground text-center mb-5">退出后需重新登录才能使用</p>
            <div className="flex flex-row gap-3">
              <button
                type="button"
                onClick={() => setShowLogout(false)}
                className="flex-1 flex items-center justify-center leading-none break-keep rounded-xl bg-muted">
                <div className="py-3 px-4">
                  <span className="text-xl text-muted-foreground font-semibold">取消</span>
                </div>
              </button>
              <button
                type="button"
                onClick={handleLogout}
                className="flex-1 flex items-center justify-center leading-none break-keep rounded-xl bg-destructive">
                <div className="py-3 px-4">
                  <span className="text-xl text-white font-semibold">退出</span>
                </div>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}