// @title 隐私政策
import Taro from '@tarojs/taro'

export default function Privacy() {
  return (
    <div className="min-h-screen bg-background px-4 py-6">
      <div className="bg-card rounded-2xl shadow-card p-6">
        <h1 className="text-2xl font-bold text-foreground mb-4">隐私政策</h1>

        <div className="flex flex-col gap-4">
          <div>
            <h2 className="text-xl font-bold text-foreground mb-2">一、信息收集</h2>
            <p className="text-xl text-muted-foreground leading-relaxed">
              本系统在您使用过程中会收集以下信息：微信昵称（用于后台数据追溯）、您选择的身份（领导/员工）和所属科室（用于数据分组统计）。
            </p>
          </div>

          <div>
            <h2 className="text-xl font-bold text-foreground mb-2">二、信息使用</h2>
            <p className="text-xl text-muted-foreground leading-relaxed">
              收集的信息仅用于部门内部员工互评打分的数据统计与分析。前台所有评价结果完全匿名，不会展示评价者的微信昵称、头像或任何个人信息。
            </p>
          </div>

          <div>
            <h2 className="text-xl font-bold text-foreground mb-2">三、信息保护</h2>
            <p className="text-xl text-muted-foreground leading-relaxed">
              我们采取严格的安全措施保护您的个人信息。后台管理员查看原始数据时需输入二次验证密码，防止非授权访问。不同科室的数据相互隔离。
            </p>
          </div>

          <div>
            <h2 className="text-xl font-bold text-foreground mb-2">四、数据删除</h2>
            <p className="text-xl text-muted-foreground leading-relaxed">
              如需删除您的历史评价数据，请联系管理员处理。我们将在收到请求后及时删除相关数据。
            </p>
          </div>

          <div>
            <h2 className="text-xl font-bold text-foreground mb-2">五、合规说明</h2>
            <p className="text-xl text-muted-foreground leading-relaxed">
              本系统遵循《个人信息保护法》相关规定，仅用于内部互评用途。您有权了解、更正和删除您的个人信息。
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}