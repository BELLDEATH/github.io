// @title 个人信息清单
import Taro from '@tarojs/taro'

export default function DataList() {
  const sections = [
    {
      title: '已收集个人信息清单',
      items: [
        {type: '账户信息', name: '微信昵称', purpose: '后台数据追溯', scene: '评价提交时', status: '已收集'},
        {type: '身份信息', name: '身份（领导/员工）', purpose: '数据分组统计', scene: '身份认证时', status: '已收集'},
        {type: '组织信息', name: '所属科室', purpose: '数据分组统计', scene: '身份认证时', status: '已收集'},
        {type: '评价数据', name: '评分记录', purpose: '互评统计', scene: '提交评价时', status: '已收集'},
      ],
    },
    {
      title: '第三方信息共享清单',
      items: [
        {
          company: '微信开放平台',
          service: '微信登录',
          info: 'OpenID',
          purpose: '用户身份验证',
          scene: '登录时',
          method: 'API调用',
        },
      ],
    },
  ]

  return (
    <div className="min-h-screen bg-background px-4 py-6">
      {sections.map((section) => (
        <div key={section.title} className="bg-card rounded-2xl shadow-card p-5 mb-4">
          <div className="flex items-center gap-2 mb-4">
            <div className="i-mdi-format-list-bulleted text-2xl text-primary" />
            <span className="text-2xl font-bold text-foreground">{section.title}</span>
          </div>

          {section.title.includes('已收集') ? (
            <div className="flex flex-col gap-3">
              {section.items.map((item: any) => (
                <div key={item.name} className="bg-muted rounded-xl p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xl font-bold text-foreground">{item.name}</span>
                    <span className="text-xl text-success">{item.status}</span>
                  </div>
                  <div className="flex flex-col gap-1">
                    <span className="text-xl text-muted-foreground">类型：{item.type}</span>
                    <span className="text-xl text-muted-foreground">目的：{item.purpose}</span>
                    <span className="text-xl text-muted-foreground">场景：{item.scene}</span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="flex flex-col gap-3">
              {section.items.map((item: any) => (
                <div key={item.company} className="bg-muted rounded-xl p-4">
                  <span className="text-xl font-bold text-foreground">{item.company}</span>
                  <div className="flex flex-col gap-1 mt-2">
                    <span className="text-xl text-muted-foreground">服务：{item.service}</span>
                    <span className="text-xl text-muted-foreground">信息：{item.info}</span>
                    <span className="text-xl text-muted-foreground">目的：{item.purpose}</span>
                    <span className="text-xl text-muted-foreground">方式：{item.method}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      ))}
    </div>
  )
}