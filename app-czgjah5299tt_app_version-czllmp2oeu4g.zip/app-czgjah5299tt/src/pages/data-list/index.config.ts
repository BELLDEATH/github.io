export default definePageConfig({
  navigationBarTitleText: '个人信息清单',
  enableShareAppMessage: true,
  enableShareTimeline: true,
})
