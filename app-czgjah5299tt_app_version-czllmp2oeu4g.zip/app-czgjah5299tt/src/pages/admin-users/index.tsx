// @title 用户管理
import {useState, useCallback, useEffect} from 'react'
import Taro, {useDidShow} from '@tarojs/taro'
import {useAuth} from '@/contexts/AuthContext'
import {getAllProfiles, updateUserRole} from '@/db/api'
import type {Profile, UserRole} from '@/db/types'

export default function AdminUsers() {
  const {profile: myProfile, loading} = useAuth()
  const [profiles, setProfiles] = useState<Profile[]>([])

  const isSuperAdmin = myProfile?.role === 'super_admin'

  const loadData = useCallback(async () => {
    try {
      const allProfiles = await getAllProfiles()
      setProfiles(allProfiles)
    } catch (e) {
      console.error(e)
    }
  }, [])

  useEffect(() => {
    loadData()
  }, [loadData])

  useDidShow(() => {
    loadData()
  })

  const handleRoleChange = async (userId: string, role: UserRole) => {
    try {
      await updateUserRole(userId, role)
      Taro.showToast({title: '修改成功', icon: 'success'})
      loadData()
    } catch (e: any) {
      Taro.showToast({title: e.message || '修改失败', icon: 'none'})
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="i-mdi-loading text-4xl text-primary animate-spin" />
      </div>
    )
  }

  if (!isSuperAdmin) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center px-6">
        <div className="i-mdi-lock-outline text-6xl text-muted-foreground mb-4" />
        <span className="text-xl text-muted-foreground">仅超级管理员可管理用户</span>
      </div>
    )
  }

  const roleLabel = (role: UserRole) => {
    switch (role) {
      case 'super_admin':
        return '超级管理员'
      case 'admin':
        return '管理员'
      default:
        return '普通用户'
    }
  }

  return (
    <div className="min-h-screen bg-background pb-8">
      {/* 顶部 */}
      <div className="bg-gradient-primary px-6 pt-8 pb-10 rounded-b-3xl">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center">
            <div className="i-mdi-account-group-outline text-3xl text-white" />
          </div>
          <div className="flex flex-col">
            <span className="text-2xl font-bold text-white">用户管理</span>
            <span className="text-xl text-white/80">管理用户角色权限</span>
          </div>
        </div>
      </div>

      {/* 用户列表 */}
      <div className="px-4 -mt-4">
        <div className="bg-card rounded-2xl shadow-card overflow-hidden">
          {profiles.length === 0 ? (
            <div className="flex flex-col items-center py-8">
              <div className="i-mdi-account-group-outline text-5xl text-muted-foreground mb-2" />
              <span className="text-xl text-muted-foreground">暂无用户</span>
            </div>
          ) : (
            profiles.map((p, idx) => (
              <div
                key={p.id}
                className={`px-5 py-4 ${idx < profiles.length - 1 ? 'border-b border-border' : ''}`}>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                      <div className="i-mdi-account text-xl text-primary" />
                    </div>
                    <div className="flex flex-col">
                      <span className="text-xl font-bold text-foreground">{p.nickname || '匿名用户'}</span>
                      <span className="text-xl text-muted-foreground">{roleLabel(p.role)}</span>
                    </div>
                  </div>
                </div>

                {/* 角色切换 */}
                {p.id !== myProfile?.id && (
                  <div className="flex flex-row gap-2 mt-2">
                    <div
                      onClick={() => handleRoleChange(p.id, 'user')}
                      className={`px-3 py-2 rounded-lg ${p.role === 'user' ? 'bg-primary' : 'bg-muted'}`}>
                      <span className={`text-xl ${p.role === 'user' ? 'text-white' : 'text-muted-foreground'}`}>
                        用户
                      </span>
                    </div>
                    <div
                      onClick={() => handleRoleChange(p.id, 'admin')}
                      className={`px-3 py-2 rounded-lg ${p.role === 'admin' ? 'bg-primary' : 'bg-muted'}`}>
                      <span className={`text-xl ${p.role === 'admin' ? 'text-white' : 'text-muted-foreground'}`}>
                        管理员
                      </span>
                    </div>
                    <div
                      onClick={() => handleRoleChange(p.id, 'super_admin')}
                      className={`px-3 py-2 rounded-lg ${p.role === 'super_admin' ? 'bg-primary' : 'bg-muted'}`}>
                      <span className={`text-xl ${p.role === 'super_admin' ? 'text-white' : 'text-muted-foreground'}`}>
                        超管
                      </span>
                    </div>
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      </div>

      <p className="text-xl text-muted-foreground text-center mt-6 px-6 leading-relaxed">
        提示：修改用户角色后立即生效，管理员可访问后台数据
      </p>
    </div>
  )
}