// @title 原始数据
import {useState, useCallback, useEffect} from 'react'
import Taro, {useDidShow} from '@tarojs/taro'
import {useAuth} from '@/contexts/AuthContext'
import {
  getSurveyCycles,
  getAllSubmissions,
  getAllRatings,
  getEvaluatees,
  getDimensions,
  getAdminSetting,
  deleteSubmissionWithRatings,
} from '@/db/api'
import type {Submission, Rating, Evaluatee, Dimension} from '@/db/types'

export default function AdminData() {
  const {user, profile, loading} = useAuth()
  const [cycles, setCycles] = useState<{id: string; name: string; status: string}[]>([])
  const [selectedCycle, setSelectedCycle] = useState('')
  const [submissions, setSubmissions] = useState<Submission[]>([])
  const [ratings, setRatings] = useState<Rating[]>([])
  const [evaluatees, setEvaluatees] = useState<Evaluatee[]>([])
  const [dimensions, setDimensions] = useState<Dimension[]>([])
  const [unlocked, setUnlocked] = useState(false)
  const [passwordInput, setPasswordInput] = useState('')
  const [filterDept, setFilterDept] = useState('')
  const [filterIdentity, setFilterIdentity] = useState('')

  const isAdmin = profile?.role === 'admin' || profile?.role === 'super_admin'

  const loadCycles = useCallback(async () => {
    try {
      const allCycles = await getSurveyCycles()
      setCycles(allCycles)
      if (allCycles.length > 0 && !selectedCycle) {
        setSelectedCycle(allCycles[0].id)
      }
    } catch (e) {
      console.error(e)
    }
  }, [selectedCycle])

  const loadData = useCallback(async () => {
    if (!selectedCycle) return
    try {
      const [subs, rats, evals, dims] = await Promise.all([
        getAllSubmissions(selectedCycle),
        getAllRatings(selectedCycle),
        getEvaluatees(selectedCycle),
        getDimensions(),
      ])
      setSubmissions(subs)
      setRatings(rats)
      setEvaluatees(evals)
      setDimensions(dims)
    } catch (e) {
      console.error(e)
    }
  }, [selectedCycle])

  useEffect(() => {
    loadCycles()
  }, [loadCycles])

  useEffect(() => {
    if (unlocked) loadData()
  }, [unlocked, loadData])

  useDidShow(() => {
    if (unlocked) loadData()
  })

  const handleUnlock = async () => {
    try {
      const correct = await getAdminSetting('secondary_password')
      if (passwordInput === correct) {
        setUnlocked(true)
        Taro.showToast({title: '验证成功', icon: 'success'})
      } else {
        Taro.showToast({title: '密码错误', icon: 'none'})
      }
    } catch (e) {
      Taro.showToast({title: '验证失败', icon: 'none'})
    }
  }

  const handleExport = () => {
    // 构建CSV数据
    const headers = ['评价者昵称', '被评价人', '身份', '科室', ...dimensions.map((d) => d.name), '总分', '平均分']
    const rows: string[][] = []

    for (const sub of submissions) {
      if (filterDept && sub.department !== filterDept) continue
      if (filterIdentity && sub.identity !== filterIdentity) continue

      for (const ev of evaluatees) {
        const evRatings = ratings.filter((r) => r.evaluator_id === sub.user_id && r.evaluatee_id === ev.id)
        if (evRatings.length === 0) continue

        const scores = dimensions.map((dim) => {
          const r = evRatings.find((rr) => rr.dimension_id === dim.id)
          return r ? String(r.score) : ''
        })
        const total = evRatings.reduce((s, r) => s + r.score, 0)
        const avg = Math.round((total / evRatings.length) * 10) / 10

        rows.push([
          sub.nickname || '匿名',
          ev.name,
          sub.identity === 'department_leader' ? '部领导' : sub.identity === 'section_chief' ? '科长' : sub.identity === 'deputy_section_chief' ? '副科长' : '科员',
          sub.department || '未分类',
          ...scores,
          String(total),
          String(avg),
        ])
      }
    }

    if (rows.length === 0) {
      Taro.showToast({title: '无数据可导出', icon: 'none'})
      return
    }

    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n')
    const fs = Taro.getFileSystemManager()
    const filePath = `${Taro.env.USER_DATA_PATH}/export_${Date.now()}.csv`

    try {
      fs.writeFileSync(filePath, csvContent, 'utf8')
      Taro.showToast({title: '导出成功', icon: 'success'})
      // 分享文件
      Taro.shareFileMessage({
        filePath,
        fileName: `互评数据_${Date.now()}.csv`,
        success: () => {},
        fail: () => {
          Taro.showToast({title: '请通过微信发送文件', icon: 'none'})
        },
      })
    } catch (e) {
      Taro.showToast({title: '导出失败', icon: 'none'})
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="i-mdi-loading text-4xl text-primary animate-spin" />
      </div>
    )
  }

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center px-6">
        <div className="i-mdi-lock-outline text-6xl text-muted-foreground mb-4" />
        <span className="text-xl text-muted-foreground">无权限访问</span>
      </div>
    )
  }

  // 二次密码验证
  if (!unlocked) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center px-6">
        <div className="bg-card rounded-2xl shadow-card p-6 w-full max-w-sm">
          <div className="flex items-center gap-2 mb-4">
            <div className="i-mdi-lock-outline text-2xl text-primary" />
            <span className="text-2xl font-bold text-foreground">二次验证</span>
          </div>
          <p className="text-xl text-muted-foreground mb-4 leading-relaxed">
            查看原始数据需输入管理员密码，请谨慎操作
          </p>
          <div className="border-2 border-input rounded-xl px-4 py-3 bg-background overflow-hidden mb-4">
            <input
              className="w-full text-xl text-foreground bg-transparent outline-none"
              placeholder="请输入验证密码"
              type="password"
              value={passwordInput}
              onInput={(e) => {
                const ev = e as any
                setPasswordInput(ev.detail?.value ?? ev.target?.value ?? '')
              }}
            />
          </div>
          <button
            type="button"
            onClick={handleUnlock}
            className="w-full flex items-center justify-center leading-none break-keep rounded-xl bg-primary">
            <div className="py-3 px-6">
              <span className="text-xl text-primary-foreground font-semibold">验证</span>
            </div>
          </button>
        </div>
      </div>
    )
  }

  // 获取所有科室和身份用于筛选
  const allDepts = [...new Set(submissions.map((s) => s.department || '未分类'))]

  // 筛选后的提交记录
  const filteredSubs = submissions.filter((s) => {
    if (filterDept && (s.department || '未分类') !== filterDept) return false
    if (filterIdentity && s.identity !== filterIdentity) return false
    return true
  })

  return (
    <div className="min-h-screen bg-background pb-8">
      {/* 顶部 */}
      <div className="bg-gradient-primary px-6 pt-8 pb-10 rounded-b-3xl">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center">
            <div className="i-mdi-database-outline text-3xl text-white" />
          </div>
          <div className="flex flex-col flex-1">
            <span className="text-2xl font-bold text-white">原始数据</span>
            <span className="text-xl text-white/80">管理员可见 · 共 {submissions.length} 条</span>
          </div>
          <button
            type="button"
            onClick={handleExport}
            className="flex items-center justify-center leading-none break-keep rounded-xl bg-white/20">
            <div className="py-2 px-4 flex items-center gap-2">
              <div className="i-mdi-file-excel-outline text-2xl text-white" />
              <span className="text-xl text-white font-semibold">导出</span>
            </div>
          </button>
        </div>
      </div>

      {/* 筛选区 */}
      <div className="px-4 -mt-4">
        <div className="bg-card rounded-2xl shadow-card p-4">
          {/* 周期选择 */}
          <div className="mb-3">
            <span className="text-xl text-foreground font-semibold mb-2">问卷周期</span>
            <div className="flex flex-row flex-wrap gap-2 mt-2">
              {cycles.map((c) => (
                <div
                  key={c.id}
                  onClick={() => setSelectedCycle(c.id)}
                  className={`px-3 py-2 rounded-lg ${
                    selectedCycle === c.id ? 'bg-primary' : 'bg-muted'
                  }`}>
                  <span className={`text-xl ${selectedCycle === c.id ? 'text-white' : 'text-muted-foreground'}`}>
                    {c.name}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* 科室筛选 */}
          <div className="mb-3">
            <span className="text-xl text-foreground font-semibold mb-2">科室筛选</span>
            <div className="flex flex-row flex-wrap gap-2 mt-2">
              <div
                onClick={() => setFilterDept('')}
                className={`px-3 py-2 rounded-lg ${!filterDept ? 'bg-primary' : 'bg-muted'}`}>
                <span className={`text-xl ${!filterDept ? 'text-white' : 'text-muted-foreground'}`}>全部</span>
              </div>
              {allDepts.map((d) => (
                <div
                  key={d}
                  onClick={() => setFilterDept(d)}
                  className={`px-3 py-2 rounded-lg ${filterDept === d ? 'bg-primary' : 'bg-muted'}`}>
                  <span className={`text-xl ${filterDept === d ? 'text-white' : 'text-muted-foreground'}`}>{d}</span>
                </div>
              ))}
            </div>
          </div>

          {/* 身份筛选 */}
          <div className="mb-4">
            <span className="text-xl text-foreground font-semibold mb-2">身份筛选</span>
            <div className="flex flex-row flex-wrap gap-2 mt-2">
              {([
                {value: '', label: '全部'},
                {value: 'department_leader', label: '部领导'},
                {value: 'section_chief', label: '科长'},
                {value: 'deputy_section_chief', label: '副科长'},
                {value: 'staff', label: '科员'},
              ] as const).map((opt) => (
                <div
                  key={opt.value}
                  onClick={() => setFilterIdentity(opt.value)}
                  className={`px-3 py-2 rounded-lg ${filterIdentity === opt.value ? 'bg-primary' : 'bg-muted'}`}>
                  <span className={`text-xl ${filterIdentity === opt.value ? 'text-white' : 'text-muted-foreground'}`}>
                    {opt.label}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* 导出按钮 */}
          <button
            type="button"
            onClick={handleExport}
            className="w-full flex items-center justify-center leading-none break-keep rounded-xl bg-success">
            <div className="py-3 px-6 flex items-center gap-2">
              <div className="i-mdi-file-excel-outline text-2xl text-white" />
              <span className="text-xl text-white font-semibold">导出Excel</span>
            </div>
          </button>
        </div>
      </div>

      {/* 数据列表 */}
      <div className="px-4 mt-4">
        <div className="flex items-center justify-between mb-3">
          <span className="text-2xl font-bold text-foreground">评价记录</span>
          <span className="text-xl text-muted-foreground">{filteredSubs.length} 条</span>
        </div>

        {filteredSubs.length === 0 ? (
          <div className="bg-card rounded-2xl shadow-card p-8 flex flex-col items-center">
            <div className="i-mdi-inbox-outline text-5xl text-muted-foreground mb-2" />
            <span className="text-xl text-muted-foreground">暂无数据</span>
          </div>
        ) : (
          <div className="flex flex-col gap-3">
            {filteredSubs.map((sub) => (
              <div key={sub.id} className="bg-card rounded-2xl shadow-card p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                      <div className="i-mdi-account text-xl text-primary" />
                    </div>
                    <div className="flex flex-col">
                      <span className="text-xl font-bold text-foreground">{sub.nickname || '匿名'}</span>
                      <span className="text-xl text-muted-foreground">
                        {{department_leader: '部领导', section_chief: '科长', deputy_section_chief: '副科长', staff: '科员'}[sub.identity] || sub.identity} · {sub.department || '未分类'}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xl text-muted-foreground">
                      {new Date(sub.created_at).toLocaleDateString('zh-CN')}
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        Taro.showModal({
                          title: '重置填报',
                          content: `删除「${sub.nickname || '匿名'}」的提交记录及所有评分，该用户可重新填报，是否继续？`,
                          success: async (res) => {
                            if (res.confirm) {
                              try {
                                await deleteSubmissionWithRatings(sub.id, sub.user_id, selectedCycle)
                                Taro.showToast({title: '已重置', icon: 'success'})
                                loadData()
                              } catch (e: any) {
                                Taro.showToast({title: e.message || '操作失败', icon: 'none'})
                              }
                            }
                          },
                        })
                      }}
                      className="flex items-center justify-center leading-none break-keep rounded-lg bg-destructive/10">
                      <div className="py-2 px-3 flex items-center gap-1">
                        <div className="i-mdi-refresh text-xl text-destructive" />
                        <span className="text-xl text-destructive">重置</span>
                      </div>
                    </button>
                  </div>
                </div>

                {/* 评分详情 */}
                <div className="flex flex-col gap-2">
                  {evaluatees.map((ev) => {
                    const evRatings = ratings.filter(
                      (r) => r.evaluator_id === sub.user_id && r.evaluatee_id === ev.id,
                    )
                    if (evRatings.length === 0) return null
                    const avg =
                      Math.round((evRatings.reduce((s, r) => s + r.score, 0) / evRatings.length) * 10) / 10
                    return (
                      <div key={ev.id} className="bg-muted rounded-xl p-3">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-xl font-bold text-foreground">{ev.name}</span>
                          <span className="text-xl font-bold text-primary">均分 {avg}</span>
                        </div>
                        <div className="flex flex-row flex-wrap gap-2">
                          {dimensions.map((dim) => {
                            const r = evRatings.find((rr) => rr.dimension_id === dim.id)
                            return (
                              <div key={dim.id} className="flex items-center gap-1">
                                <span className="text-xl text-muted-foreground">{dim.name}:</span>
                                <span className="text-xl font-semibold text-foreground">{r?.score || '-'}</span>
                              </div>
                            )
                          })}
                        </div>
                      </div>
                    )
                  })}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}