export default definePageConfig({
  navigationBarTitleText: '原始数据',
  enableShareAppMessage: true,
  enableShareTimeline: true,
})
