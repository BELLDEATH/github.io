// @title 评价结果
import {useState, useCallback, useEffect} from 'react'
import Taro, {useDidShow} from '@tarojs/taro'
import {useAuth} from '@/contexts/AuthContext'
import {getActiveCycle, getMyRatings, getMySubmission, getEvaluatees, getDimensions} from '@/db/api'
import type {Rating, Evaluatee, Dimension, Submission} from '@/db/types'

export default function Result() {
  const {user} = useAuth()
  const [cycle, setCycle] = useState<{id: string; name: string} | null>(null)
  const [submission, setSubmission] = useState<Submission | null>(null)
  const [myRatings, setMyRatings] = useState<Rating[]>([])
  const [evaluatees, setEvaluatees] = useState<Evaluatee[]>([])
  const [dimensions, setDimensions] = useState<Dimension[]>([])
  const [loading, setLoading] = useState(true)

  const loadData = useCallback(async () => {
    if (!user) return
    setLoading(true)
    try {
      const activeCycle = await getActiveCycle()
      setCycle(activeCycle)
      if (activeCycle) {
        const [sub, ratings, evals, dims] = await Promise.all([
          getMySubmission(activeCycle.id, user.id),
          getMyRatings(activeCycle.id, user.id),
          getEvaluatees(activeCycle.id),
          getDimensions(),
        ])
        setSubmission(sub)
        setMyRatings(ratings)
        setEvaluatees(evals)
        setDimensions(dims)
      }
    } catch (e) {
      console.error('加载失败:', e)
    }
    setLoading(false)
  }, [user])

  useEffect(() => {
    loadData()
  }, [loadData])

  useDidShow(() => {
    loadData()
  })

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="i-mdi-loading text-4xl text-primary animate-spin" />
      </div>
    )
  }

  if (!cycle) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center px-6">
        <div className="i-mdi-inbox-outline text-6xl text-muted-foreground mb-4" />
        <span className="text-xl text-muted-foreground">暂无问卷数据</span>
      </div>
    )
  }

  if (!submission) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center px-6">
        <div className="i-mdi-clipboard-edit-outline text-6xl text-muted-foreground mb-4" />
        <span className="text-xl text-muted-foreground mb-4">您尚未提交评价</span>
        <button
          type="button"
          onClick={() => Taro.navigateTo({url: '/pages/identity/index'})}
          className="flex items-center justify-center leading-none break-keep rounded-xl bg-primary">
          <div className="py-3 px-8">
            <span className="text-xl text-primary-foreground font-semibold">去评价</span>
          </div>
        </button>
      </div>
    )
  }

  // 按被评价人分组
  const getRatingsForEvaluatee = (evaluateeId: string) =>
    myRatings.filter((r) => r.evaluatee_id === evaluateeId)

  const getAvgForEvaluatee = (evaluateeId: string) => {
    const ratings = getRatingsForEvaluatee(evaluateeId)
    if (ratings.length === 0) return 0
    return Math.round((ratings.reduce((s, r) => s + r.score, 0) / ratings.length) * 10) / 10
  }

  return (
    <div className="min-h-screen bg-background pb-8">
      {/* 顶部状态 */}
      <div className="bg-gradient-primary px-6 pt-8 pb-10 rounded-b-3xl">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center">
            <div className="i-mdi-check-circle text-3xl text-white" />
          </div>
          <div className="flex flex-col">
            <span className="text-2xl font-bold text-white">评价已完成</span>
            <span className="text-xl text-white/80">{cycle.name}</span>
          </div>
        </div>
      </div>

      {/* 提交信息 */}
      <div className="px-4 -mt-4">
        <div className="bg-card rounded-2xl shadow-card p-4">
          <div className="flex flex-row gap-4">
            <div className="flex-1 flex flex-col items-center">
              <span className="text-2xl font-bold text-primary">{evaluatees.length}</span>
              <span className="text-xl text-muted-foreground">评价人数</span>
            </div>
            <div className="flex-1 flex flex-col items-center">
              <span className="text-2xl font-bold text-accent">{dimensions.length}</span>
              <span className="text-xl text-muted-foreground">评价维度</span>
            </div>
            <div className="flex-1 flex flex-col items-center">
              <span className="text-2xl font-bold text-success">
                {{department_leader: '部领导', section_chief: '科长', deputy_section_chief: '副科长', staff: '科员'}[submission.identity] || submission.identity}
              </span>
              <span className="text-xl text-muted-foreground">您的身份</span>
            </div>
          </div>
        </div>
      </div>

      {/* 我的评分详情 */}
      <div className="px-4 mt-4">
        <div className="flex items-center gap-2 mb-3">
          <div className="i-mdi-format-list-bulleted text-2xl text-primary" />
          <span className="text-2xl font-bold text-foreground">我的评分</span>
        </div>

        {evaluatees.map((evaluatee) => {
          const ratings = getRatingsForEvaluatee(evaluatee.id)
          const avg = getAvgForEvaluatee(evaluatee.id)
          return (
            <div key={evaluatee.id} className="bg-card rounded-2xl shadow-card p-4 mb-3">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                    <div className="i-mdi-account text-xl text-primary" />
                  </div>
                  <span className="text-xl font-bold text-foreground">{evaluatee.name}</span>
                </div>
                <div className="flex items-center gap-1">
                  <span className="text-xl text-muted-foreground">均分</span>
                  <span className="text-2xl font-bold text-primary">{avg}</span>
                </div>
              </div>
              <div className="flex flex-col gap-2">
                {dimensions.map((dim) => {
                  const rating = ratings.find((r) => r.dimension_id === dim.id)
                  return (
                    <div key={dim.id} className="flex items-center justify-between">
                      <span className="text-xl text-muted-foreground">{dim.name}</span>
                      <div className="flex items-center gap-1">
                        <div className="w-24 h-2 bg-muted rounded-full overflow-hidden">
                          <div
                            className="h-full bg-primary rounded-full"
                            style={{width: `${(rating?.score || 0) * 10}%`}}
                          />
                        </div>
                        <span className="text-xl font-semibold text-foreground w-8 text-right">
                          {rating?.score || '-'}
                        </span>
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>
          )
        })}
      </div>

      <p className="text-xl text-muted-foreground text-center mt-6 px-6 leading-relaxed">
        以上为您的个人评分记录，他人评价数据完全匿名
      </p>
    </div>
  )
}