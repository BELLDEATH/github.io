export default definePageConfig({
  navigationBarTitleText: '评价结果',
  enableShareAppMessage: true,
  enableShareTimeline: true,
})
