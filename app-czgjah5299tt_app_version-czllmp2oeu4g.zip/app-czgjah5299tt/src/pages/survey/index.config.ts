export default definePageConfig({
  navigationBarTitleText: '问卷打分',
  enableShareAppMessage: true,
  enableShareTimeline: true,
})
