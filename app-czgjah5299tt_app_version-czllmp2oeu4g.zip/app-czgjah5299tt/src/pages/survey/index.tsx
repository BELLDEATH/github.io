// @title 问卷打分
import {useState, useCallback, useEffect, useMemo} from 'react'
import Taro from '@tarojs/taro'
import {Picker} from '@tarojs/components'
import {useAuth} from '@/contexts/AuthContext'
import {
  getActiveCycle,
  getEvaluatees,
  getDimensions,
  createSubmission,
  createRatings,
  getMySubmission,
} from '@/db/api'
import type {Evaluatee, Dimension, IdentityType} from '@/db/types'

// 分数选项：10→1 倒序
const SCORES = Array.from({length: 10}, (_, i) => `${10 - i}分`)
// 分数 → Picker 索引（10分=0, 9分=1, ...）
const scoreToIndex = (score: number) => 10 - score
// Picker 索引 → 分数
const indexToScore = (idx: number) => 10 - idx

// 是否属于领导职级（需要额外的管理领导力维度）
const isLeaderIdentity = (id: IdentityType) =>
  id === 'department_leader' || id === 'section_chief' || id === 'deputy_section_chief'

const IDENTITY_LABELS: Record<string, string> = {
  department_leader: '部领导',
  section_chief: '科长',
  deputy_section_chief: '副科长',
  staff: '科员',
}

// 身份分组顺序
const IDENTITY_ORDER: IdentityType[] = ['department_leader', 'section_chief', 'deputy_section_chief', 'staff']

export default function Survey() {
  const {user, profile} = useAuth()
  const [cycle, setCycle] = useState<{id: string; name: string} | null>(null)
  const [evaluatees, setEvaluatees] = useState<Evaluatee[]>([])
  const [dimensions, setDimensions] = useState<Dimension[]>([])
  const [scores, setScores] = useState<Record<string, number>>({})
  const [submitting, setSubmitting] = useState(false)
  const [loading, setLoading] = useState(true)
  const [activeGroup, setActiveGroup] = useState<IdentityType | null>(null)

  const identity = useMemo<IdentityType>(
    () => (Taro.getStorageSync('survey_identity') as IdentityType) || 'staff',
    [],
  )
  const department = useMemo(() => Taro.getStorageSync('survey_department') || '', [])

  const loadData = useCallback(async () => {
    if (!user) return
    setLoading(true)
    try {
      const activeCycle = await getActiveCycle()
      if (!activeCycle) {
        Taro.showToast({title: '无进行中的问卷', icon: 'none'})
        setLoading(false)
        return
      }
      setCycle(activeCycle)

      const sub = await getMySubmission(activeCycle.id, user.id)
      if (sub) {
        Taro.showToast({title: '您已提交过评价', icon: 'none'})
        setTimeout(() => Taro.switchTab({url: '/pages/result/index'}), 1000)
        setLoading(false)
        return
      }

      const [evals, dims] = await Promise.all([
        getEvaluatees(activeCycle.id),
        getDimensions(),
      ])
      setEvaluatees(evals)
      setDimensions(dims)
      // 默认选中第一个有数据的分组
      const firstGroup = IDENTITY_ORDER.find((id) => evals.some((ev) => ev.identity === id))
      if (firstGroup) setActiveGroup(firstGroup)
    } catch (e) {
      console.error('加载失败:', e)
    }
    setLoading(false)
  }, [user])

  useEffect(() => {
    loadData()
  }, [loadData])

  // 根据被评价人身份获取适用维度
  const getDimsForEvaluatee = useCallback(
    (evaluatee: Evaluatee) => {
      if (isLeaderIdentity(evaluatee.identity)) return dimensions
      return dimensions.filter((d) => !d.leader_only)
    },
    [dimensions],
  )

  const getScoreKey = (evaluateeId: string, dimensionId: string) => `${evaluateeId}_${dimensionId}`

  const setScore = (evaluateeId: string, dimensionId: string, score: number) => {
    setScores((prev) => ({...prev, [getScoreKey(evaluateeId, dimensionId)]: score}))
  }

  // 每位被评价人是否完成
  const isEvaluateeComplete = useCallback(
    (evaluatee: Evaluatee) => {
      const dims = getDimsForEvaluatee(evaluatee)
      return dims.length > 0 && dims.every((d) => scores[getScoreKey(evaluatee.id, d.id)] !== undefined)
    },
    [getDimsForEvaluatee, scores],
  )

  // 有被评价人的分组（按固定顺序）
  const activeGroups = useMemo(
    () => IDENTITY_ORDER.filter((id) => evaluatees.some((ev) => ev.identity === id)),
    [evaluatees],
  )

  // 当前分组的被评价人
  const groupEvaluatees = useMemo(
    () => (activeGroup ? evaluatees.filter((ev) => ev.identity === activeGroup) : []),
    [evaluatees, activeGroup],
  )

  const completedEvaluatees = evaluatees.filter(isEvaluateeComplete).length
  const totalCount = useMemo(
    () => evaluatees.reduce((sum, ev) => sum + getDimsForEvaluatee(ev).length, 0),
    [evaluatees, getDimsForEvaluatee],
  )
  const completedCount = useMemo(
    () =>
      evaluatees.reduce((sum, ev) => {
        const dims = getDimsForEvaluatee(ev)
        return sum + dims.filter((d) => scores[getScoreKey(ev.id, d.id)] !== undefined).length
      }, 0),
    [evaluatees, getDimsForEvaluatee, scores],
  )
  const progress = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0

  // 当前分组是否全部完成
  const isGroupComplete = useMemo(
    () => groupEvaluatees.every(isEvaluateeComplete),
    [groupEvaluatees, isEvaluateeComplete],
  )

  const handleSubmit = async () => {
    if (!user || !cycle) return
    if (completedCount < totalCount) {
      Taro.showToast({
        title: `请完成所有打分（${completedEvaluatees}/${evaluatees.length}人）`,
        icon: 'none',
      })
      return
    }

    setSubmitting(true)
    try {
      await createSubmission({
        cycle_id: cycle.id,
        user_id: user.id,
        nickname: profile?.nickname || null,
        identity,
        department: department || null,
      })

      const ratings = evaluatees.flatMap((ev) =>
        getDimsForEvaluatee(ev).map((dim) => ({
          cycle_id: cycle.id,
          evaluator_id: user.id,
          evaluatee_id: ev.id,
          dimension_id: dim.id,
          score: scores[getScoreKey(ev.id, dim.id)],
        })),
      )
      await createRatings(ratings)

      Taro.showToast({title: '提交成功', icon: 'success'})
      setTimeout(() => Taro.switchTab({url: '/pages/result/index'}), 1500)
    } catch (e: any) {
      Taro.showToast({title: e.message || '提交失败', icon: 'none'})
    }
    setSubmitting(false)
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="i-mdi-loading text-4xl text-primary animate-spin" />
      </div>
    )
  }

  if (!cycle || evaluatees.length === 0) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center px-6">
        <div className="i-mdi-inbox-outline text-6xl text-muted-foreground mb-4" />
        <span className="text-xl text-muted-foreground">暂无可评价的对象</span>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background pb-28">
      {/* 顶部进度 */}
      <div className="bg-card shadow-card px-4 py-4 sticky top-0 z-10">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xl font-bold text-foreground">{cycle.name}</span>
          <span className="text-xl text-primary font-semibold">{progress}%</span>
        </div>
        <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
          <div
            className="h-full bg-primary rounded-full transition-all"
            style={{width: `${progress}%`}}
          />
        </div>
        <div className="flex items-center justify-between mt-1">
          <span className="text-xl text-muted-foreground">已完成 {completedCount}/{totalCount} 项</span>
          <span className="text-xl text-success font-semibold">
            {completedEvaluatees}/{evaluatees.length} 人
          </span>
        </div>

        {/* 身份分组 Tab */}
        <div className="flex flex-row gap-2 mt-3">
          {activeGroups.map((gid) => {
            const groupEvs = evaluatees.filter((ev) => ev.identity === gid)
            const groupDone = groupEvs.every(isEvaluateeComplete)
            const isActive = activeGroup === gid
            return (
              <div
                key={gid}
                onClick={() => setActiveGroup(gid)}
                className={`flex-1 flex flex-col items-center py-2 rounded-xl border-2 transition ${
                  isActive
                    ? 'border-primary bg-primary/5'
                    : groupDone
                    ? 'border-success bg-success/5'
                    : 'border-border bg-background'
                }`}>
                {groupDone && (
                  <div className="i-mdi-check-circle text-xl text-success mb-0.5" />
                )}
                <span
                  className={`text-xl font-semibold ${
                    isActive ? 'text-primary' : groupDone ? 'text-success' : 'text-muted-foreground'
                  }`}>
                  {IDENTITY_LABELS[gid]}
                </span>
                <span className="text-xl text-muted-foreground">{groupEvs.length}人</span>
              </div>
            )
          })}
        </div>
      </div>

      {/* 当前分组打分 */}
      <div className="px-4 py-4">
        {/* 分组标题 */}
        {activeGroup && (
          <div className="flex items-center gap-2 mb-3">
            <div className="w-1 h-6 bg-primary rounded-full" />
            <span className="text-2xl font-bold text-foreground">
              {IDENTITY_LABELS[activeGroup]}
            </span>
            <span className="text-xl text-muted-foreground">
              （共 {groupEvaluatees.length} 人）
            </span>
            {isGroupComplete && (
              <div className="flex items-center gap-1 bg-success/15 rounded-full px-2 py-0.5 ml-auto">
                <div className="i-mdi-check-circle text-xl text-success" />
                <span className="text-xl text-success font-semibold">全组完成</span>
              </div>
            )}
          </div>
        )}

        {groupEvaluatees.map((evaluatee, evIdx) => {
          const evDims = getDimsForEvaluatee(evaluatee)
          const complete = isEvaluateeComplete(evaluatee)
          return (
            <div
              key={evaluatee.id}
              className={`rounded-2xl shadow-card p-4 mb-4 border-2 transition ${
                complete ? 'bg-success/5 border-success' : 'bg-card border-transparent'
              }`}>
              {/* 被评价人标题 */}
              <div className="flex items-center gap-2 mb-4 pb-3 border-b border-border">
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center ${
                    complete ? 'bg-success' : 'bg-primary/10'
                  }`}>
                  {complete ? (
                    <div className="i-mdi-check text-xl text-white" />
                  ) : (
                    <span className="text-xl text-primary font-bold">{evIdx + 1}</span>
                  )}
                </div>
                <div className="flex flex-col flex-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xl font-bold text-foreground">{evaluatee.name}</span>
                    {complete && (
                      <div className="flex items-center gap-1 bg-success/15 rounded-full px-2 py-0.5">
                        <div className="i-mdi-check-circle text-xl text-success" />
                        <span className="text-xl text-success font-semibold">已完成</span>
                      </div>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xl text-muted-foreground">{evaluatee.department || '未分类'}</span>
                    <span className="text-xl text-muted-foreground">·</span>
                    <span className="text-xl text-muted-foreground">{evDims.length}项评价</span>
                  </div>
                </div>
              </div>

              {/* 维度打分 */}
              <div className="flex flex-col gap-3">
                {evDims.map((dim) => {
                  const key = getScoreKey(evaluatee.id, dim.id)
                  const currentScore = scores[key]
                  return (
                    <div key={dim.id} className="flex items-center justify-between">
                      <div className="flex items-center gap-1 flex-1">
                        <span className="text-xl text-foreground">{dim.name}</span>
                        {dim.leader_only && (
                          <span className="text-xl text-accent">★</span>
                        )}
                      </div>
                      <Picker
                        mode="selector"
                        range={SCORES}
                        value={currentScore !== undefined ? scoreToIndex(currentScore) : 0}
                        onChange={(e) =>
                          setScore(evaluatee.id, dim.id, indexToScore(Number(e.detail.value)))
                        }>
                        <div
                          className={`px-4 py-2 rounded-lg border-2 flex items-center gap-1 ${
                            currentScore !== undefined ? 'border-primary bg-primary/5' : 'border-border bg-background'
                          }`}>
                          <span
                            className={`text-xl font-semibold ${
                              currentScore !== undefined ? 'text-primary' : 'text-muted-foreground'
                            }`}>
                            {currentScore !== undefined ? `${currentScore}分` : '选择'}
                          </span>
                          <div className="i-mdi-chevron-down text-xl text-muted-foreground" />
                        </div>
                      </Picker>
                    </div>
                  )
                })}
              </div>
            </div>
          )
        })}

        {/* 切换下一组提示 */}
        {isGroupComplete && activeGroup && (() => {
          const currentIdx = activeGroups.indexOf(activeGroup)
          const nextGroup = activeGroups[currentIdx + 1]
          return nextGroup ? (
            <button
              type="button"
              onClick={() => setActiveGroup(nextGroup)}
              className="w-full flex items-center justify-center leading-none break-keep rounded-xl bg-success mb-4">
              <div className="py-3 px-6 flex items-center gap-2">
                <span className="text-xl text-white font-semibold">
                  下一组：{IDENTITY_LABELS[nextGroup]}
                </span>
                <div className="i-mdi-arrow-right text-2xl text-white" />
              </div>
            </button>
          ) : null
        })()}
      </div>

      {/* 底部提交栏 */}
      <div className="fixed bottom-0 left-0 right-0 bg-card shadow-card px-4 py-4">
        <button
          type="button"
          onClick={handleSubmit}
          className={`w-full flex items-center justify-center leading-none break-keep rounded-xl ${
            submitting ? 'bg-primary/50' : completedCount < totalCount ? 'bg-muted' : 'bg-primary'
          }`}>
          <div className="py-4 px-6 flex items-center gap-2">
            <div className={`i-mdi-send-outline text-2xl ${completedCount < totalCount ? 'text-muted-foreground' : 'text-white'}`} />
            <span className={`text-xl font-semibold ${completedCount < totalCount ? 'text-muted-foreground' : 'text-primary-foreground'}`}>
              {submitting
                ? '提交中...'
                : completedCount < totalCount
                ? `尚未完成（${completedEvaluatees}/${evaluatees.length}人）`
                : `提交评价（全部${evaluatees.length}人完成）`}
            </span>
          </div>
        </button>
      </div>
    </div>
  )
}

