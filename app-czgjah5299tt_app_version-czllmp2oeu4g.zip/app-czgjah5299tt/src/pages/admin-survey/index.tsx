// @title 问卷管理
import {useState, useCallback, useEffect} from 'react'
import Taro, {useDidShow} from '@tarojs/taro'
import {useAuth} from '@/contexts/AuthContext'
import {
  getSurveyCycles,
  createSurveyCycle,
  updateSurveyCycleStatus,
  deleteSurveyCycle,
  getDimensions,
  addDimension,
  deleteDimension,
  getEvaluatees,
  addEvaluatee,
  deleteEvaluatee,
  getDepartments,
} from '@/db/api'
import type {SurveyCycle, Dimension, Evaluatee, Department} from '@/db/types'

export default function AdminSurvey() {
  const {profile, loading} = useAuth()
  const [cycles, setCycles] = useState<SurveyCycle[]>([])
  const [dimensions, setDimensions] = useState<Dimension[]>([])
  const [evaluatees, setEvaluatees] = useState<Evaluatee[]>([])
  const [departments, setDepartments] = useState<Department[]>([])
  const [activeCycle, setActiveCycle] = useState<SurveyCycle | null>(null)
  const [newCycleName, setNewCycleName] = useState('')
  const [newDimName, setNewDimName] = useState('')
  const [newEvName, setNewEvName] = useState('')
  const [newEvIdentity, setNewEvIdentity] = useState<'department_leader' | 'section_chief' | 'deputy_section_chief' | 'staff'>('staff')
  const [tab, setTab] = useState<'cycle' | 'dimension' | 'evaluatee'>('cycle')

  const isSuperAdmin = profile?.role === 'super_admin'

  const loadData = useCallback(async () => {
    try {
      const [allCycles, dims, depts] = await Promise.all([
        getSurveyCycles(),
        getDimensions(),
        getDepartments(),
      ])
      setCycles(allCycles)
      setDimensions(dims)
      setDepartments(depts)
      const active = allCycles.find((c) => c.status === 'active')
      setActiveCycle(active || null)
      if (active) {
        const evals = await getEvaluatees(active.id)
        setEvaluatees(evals)
      }
    } catch (e) {
      console.error(e)
    }
  }, [])

  useEffect(() => {
    loadData()
  }, [loadData])

  useDidShow(() => {
    loadData()
  })

  const handleCreateCycle = async () => {
    if (!newCycleName.trim()) {
      Taro.showToast({title: '请输入问卷名称', icon: 'none'})
      return
    }
    try {
      await createSurveyCycle(newCycleName.trim())
      setNewCycleName('')
      Taro.showToast({title: '创建成功', icon: 'success'})
      loadData()
    } catch (e: any) {
      Taro.showToast({title: e.message || '创建失败', icon: 'none'})
    }
  }

  const handleStatusChange = async (cycle: SurveyCycle, status: 'draft' | 'active' | 'closed') => {
    try {
      await updateSurveyCycleStatus(cycle.id, status)
      Taro.showToast({title: '操作成功', icon: 'success'})
      loadData()
    } catch (e: any) {
      Taro.showToast({title: e.message || '操作失败', icon: 'none'})
    }
  }

  const handleDeleteCycle = async (id: string) => {
    Taro.showModal({
      title: '确认删除',
      content: '删除后数据不可恢复',
      success: async (res) => {
        if (res.confirm) {
          try {
            await deleteSurveyCycle(id)
            Taro.showToast({title: '已删除', icon: 'success'})
            loadData()
          } catch (e: any) {
            Taro.showToast({title: e.message || '删除失败', icon: 'none'})
          }
        }
      },
    })
  }

  const handleAddDimension = async () => {
    if (!newDimName.trim()) {
      Taro.showToast({title: '请输入维度名称', icon: 'none'})
      return
    }
    try {
      await addDimension(newDimName.trim())
      setNewDimName('')
      Taro.showToast({title: '添加成功', icon: 'success'})
      loadData()
    } catch (e: any) {
      Taro.showToast({title: e.message || '添加失败', icon: 'none'})
    }
  }

  const handleDeleteDimension = async (id: string) => {
    Taro.showModal({
      title: '确认删除',
      content: '删除后相关评分数据将丢失',
      success: async (res) => {
        if (res.confirm) {
          try {
            await deleteDimension(id)
            Taro.showToast({title: '已删除', icon: 'success'})
            loadData()
          } catch (e: any) {
            Taro.showToast({title: e.message || '删除失败', icon: 'none'})
          }
        }
      },
    })
  }

  const handleAddEvaluatee = async () => {
    if (!newEvName.trim()) {
      Taro.showToast({title: '请输入姓名', icon: 'none'})
      return
    }
    if (!activeCycle) {
      Taro.showToast({title: '请先启用一个问卷', icon: 'none'})
      return
    }
    try {
      await addEvaluatee({
        name: newEvName.trim(),
        department: null,
        identity: newEvIdentity,
        cycle_id: activeCycle.id,
      })
      setNewEvName('')
      Taro.showToast({title: '添加成功', icon: 'success'})
      loadData()
    } catch (e: any) {
      Taro.showToast({title: e.message || '添加失败', icon: 'none'})
    }
  }

  const handleDeleteEvaluatee = async (id: string) => {
    Taro.showModal({
      title: '确认删除',
      content: '删除后相关评分数据将丢失',
      success: async (res) => {
        if (res.confirm) {
          try {
            await deleteEvaluatee(id)
            Taro.showToast({title: '已删除', icon: 'success'})
            loadData()
          } catch (e: any) {
            Taro.showToast({title: e.message || '删除失败', icon: 'none'})
          }
        }
      },
    })
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="i-mdi-loading text-4xl text-primary animate-spin" />
      </div>
    )
  }

  if (!isSuperAdmin) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center px-6">
        <div className="i-mdi-lock-outline text-6xl text-muted-foreground mb-4" />
        <span className="text-xl text-muted-foreground">仅超级管理员可管理问卷</span>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background pb-8">
      {/* 顶部 */}
      <div className="bg-gradient-primary px-6 pt-8 pb-10 rounded-b-3xl">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center">
            <div className="i-mdi-clipboard-edit-outline text-3xl text-white" />
          </div>
          <div className="flex flex-col">
            <span className="text-2xl font-bold text-white">问卷管理</span>
            <span className="text-xl text-white/80">配置问卷周期与评价维度</span>
          </div>
        </div>
      </div>

      {/* Tab切换 */}
      <div className="px-4 -mt-4">
        <div className="bg-card rounded-2xl shadow-card overflow-hidden">
          <div className="flex flex-row">
            <div
              onClick={() => setTab('cycle')}
              className={`flex-1 flex items-center justify-center py-3 ${
                tab === 'cycle' ? 'border-b-2 border-primary' : ''
              }`}>
              <span className={`text-xl ${tab === 'cycle' ? 'text-primary font-bold' : 'text-muted-foreground'}`}>
                问卷周期
              </span>
            </div>
            <div
              onClick={() => setTab('dimension')}
              className={`flex-1 flex items-center justify-center py-3 ${
                tab === 'dimension' ? 'border-b-2 border-primary' : ''
              }`}>
              <span className={`text-xl ${tab === 'dimension' ? 'text-primary font-bold' : 'text-muted-foreground'}`}>
                评价维度
              </span>
            </div>
            <div
              onClick={() => setTab('evaluatee')}
              className={`flex-1 flex items-center justify-center py-3 ${
                tab === 'evaluatee' ? 'border-b-2 border-primary' : ''
              }`}>
              <span className={`text-xl ${tab === 'evaluatee' ? 'text-primary font-bold' : 'text-muted-foreground'}`}>
                被评价人
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* 内容区 */}
      <div className="px-4 mt-4">
        {tab === 'cycle' && (
          <div className="flex flex-col gap-4">
            {/* 新建问卷 */}
            <div className="bg-card rounded-2xl shadow-card p-4">
              <span className="text-xl font-bold text-foreground mb-3">新建问卷周期</span>
              <div className="border-2 border-input rounded-xl px-4 py-3 bg-background overflow-hidden mb-3">
                <input
                  className="w-full text-xl text-foreground bg-transparent outline-none"
                  placeholder="请输入问卷名称"
                  value={newCycleName}
                  onInput={(e) => {
                    const ev = e as any
                    setNewCycleName(ev.detail?.value ?? ev.target?.value ?? '')
                  }}
                />
              </div>
              <button
                type="button"
                onClick={handleCreateCycle}
                className="w-full flex items-center justify-center leading-none break-keep rounded-xl bg-primary">
                <div className="py-3 px-6 flex items-center gap-2">
                  <div className="i-mdi-plus text-2xl text-white" />
                  <span className="text-xl text-primary-foreground font-semibold">创建</span>
                </div>
              </button>
            </div>

            {/* 问卷列表 */}
            {cycles.map((cycle) => (
              <div key={cycle.id} className="bg-card rounded-2xl shadow-card p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex flex-col">
                    <span className="text-xl font-bold text-foreground">{cycle.name}</span>
                    <span className="text-xl text-muted-foreground">
                      {cycle.status === 'active' ? '进行中' : cycle.status === 'draft' ? '未开始' : '已结束'}
                    </span>
                  </div>
                  <div className="flex flex-row gap-2">
                    <button
                      type="button"
                      onClick={() =>
                        Taro.navigateTo({
                          url: `/pages/admin-survey-edit/index?id=${encodeURIComponent(cycle.id)}`,
                        })
                      }
                      className="flex items-center justify-center leading-none break-keep rounded-lg bg-primary/10">
                      <div className="py-2 px-3 flex items-center gap-1">
                        <div className="i-mdi-pencil text-xl text-primary" />
                        <span className="text-xl text-primary">编辑</span>
                      </div>
                    </button>
                    {cycle.status === 'draft' && (
                      <button
                        type="button"
                        onClick={() => handleStatusChange(cycle, 'active')}
                        className="flex items-center justify-center leading-none break-keep rounded-lg bg-success">
                        <div className="py-2 px-3">
                          <span className="text-xl text-white">启用</span>
                        </div>
                      </button>
                    )}
                    {cycle.status === 'active' && (
                      <button
                        type="button"
                        onClick={() => handleStatusChange(cycle, 'closed')}
                        className="flex items-center justify-center leading-none break-keep rounded-lg bg-muted">
                        <div className="py-2 px-3">
                          <span className="text-xl text-muted-foreground">停用</span>
                        </div>
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => handleDeleteCycle(cycle.id)}
                      className="flex items-center justify-center leading-none break-keep rounded-lg bg-destructive/10">
                      <div className="py-2 px-3">
                        <span className="text-xl text-destructive">删除</span>
                      </div>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {tab === 'dimension' && (
          <div className="flex flex-col gap-4">
            {/* 添加维度 */}
            <div className="bg-card rounded-2xl shadow-card p-4">
              <span className="text-xl font-bold text-foreground mb-3">添加评价维度</span>
              <div className="flex flex-row gap-2">
                <div className="flex-1 border-2 border-input rounded-xl px-4 py-3 bg-background overflow-hidden">
                  <input
                    className="w-full text-xl text-foreground bg-transparent outline-none"
                    placeholder="维度名称"
                    value={newDimName}
                    onInput={(e) => {
                      const ev = e as any
                      setNewDimName(ev.detail?.value ?? ev.target?.value ?? '')
                    }}
                  />
                </div>
                <button
                  type="button"
                  onClick={handleAddDimension}
                  className="flex items-center justify-center leading-none break-keep rounded-xl bg-primary">
                  <div className="py-3 px-4">
                    <div className="i-mdi-plus text-2xl text-white" />
                  </div>
                </button>
              </div>
            </div>

            {/* 维度列表 */}
            <div className="bg-card rounded-2xl shadow-card overflow-hidden">
              {dimensions.map((dim, idx) => (
                <div
                  key={dim.id}
                  className={`flex items-center justify-between px-5 py-4 ${
                    idx < dimensions.length - 1 ? 'border-b border-border' : ''
                  }`}>
                  <div className="flex items-center gap-2">
                    <span className="text-xl text-muted-foreground">{idx + 1}.</span>
                    <span className="text-xl font-bold text-foreground">{dim.name}</span>
                  </div>
                  <div onClick={() => handleDeleteDimension(dim.id)}>
                    <div className="i-mdi-delete-outline text-2xl text-destructive" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {tab === 'evaluatee' && (
          <div className="flex flex-col gap-4">
            {!activeCycle ? (
              <div className="bg-card rounded-2xl shadow-card p-6 flex flex-col items-center">
                <div className="i-mdi-alert-circle-outline text-4xl text-muted-foreground mb-2" />
                <span className="text-xl text-muted-foreground">请先启用一个问卷周期</span>
              </div>
            ) : (
              <>
                {/* 添加被评价人 */}
                <div className="bg-card rounded-2xl shadow-card p-4">
                  <span className="text-xl font-bold text-foreground mb-3">
                    添加被评价人（当前问卷：{activeCycle.name}）
                  </span>
                  <div className="border-2 border-input rounded-xl px-4 py-3 bg-background overflow-hidden mb-3">
                    <input
                      className="w-full text-xl text-foreground bg-transparent outline-none"
                      placeholder="姓名"
                      value={newEvName}
                      onInput={(e) => {
                        const ev = e as any
                        setNewEvName(ev.detail?.value ?? ev.target?.value ?? '')
                      }}
                    />
                  </div>
                  <div className="flex flex-row gap-2 mb-3">
                    <div className="flex flex-row bg-muted rounded-xl overflow-hidden flex-1">
                      {([
                        {value: 'staff', label: '科员'},
                        {value: 'deputy_section_chief', label: '副科长'},
                        {value: 'section_chief', label: '科长'},
                        {value: 'department_leader', label: '部领导'},
                      ] as const).map((opt) => (
                        <div
                          key={opt.value}
                          onClick={() => setNewEvIdentity(opt.value)}
                          className={`flex-1 px-2 py-2 flex items-center justify-center ${newEvIdentity === opt.value ? 'bg-primary' : ''}`}>
                          <span className={`text-xl ${newEvIdentity === opt.value ? 'text-white' : 'text-muted-foreground'}`}>
                            {opt.label}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={handleAddEvaluatee}
                    className="w-full flex items-center justify-center leading-none break-keep rounded-xl bg-primary">
                    <div className="py-3 px-6 flex items-center gap-2">
                      <div className="i-mdi-plus text-2xl text-white" />
                      <span className="text-xl text-primary-foreground font-semibold">添加</span>
                    </div>
                  </button>
                </div>

                {/* 被评价人列表 */}
                <div className="bg-card rounded-2xl shadow-card overflow-hidden">
                  {evaluatees.length === 0 ? (
                    <div className="flex flex-col items-center py-8">
                      <div className="i-mdi-account-group-outline text-4xl text-muted-foreground mb-2" />
                      <span className="text-xl text-muted-foreground">暂无被评价人</span>
                    </div>
                  ) : (
                    evaluatees.map((ev, idx) => (
                      <div
                        key={ev.id}
                        className={`flex items-center justify-between px-5 py-4 ${
                          idx < evaluatees.length - 1 ? 'border-b border-border' : ''
                        }`}>
                        <div className="flex items-center gap-2">
                          <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                            <span className="text-xl text-primary font-bold">{idx + 1}</span>
                          </div>
                          <div className="flex flex-col">
                            <span className="text-xl font-bold text-foreground">{ev.name}</span>
                            <span className="text-xl text-muted-foreground">
                              {{department_leader: '部领导', section_chief: '科长', deputy_section_chief: '副科长', staff: '科员'}[ev.identity] || ev.identity}
                            </span>
                          </div>
                        </div>
                        <div onClick={() => handleDeleteEvaluatee(ev.id)}>
                          <div className="i-mdi-delete-outline text-2xl text-destructive" />
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </>
            )}
          </div>
        )}
      </div>
    </div>
  )
}