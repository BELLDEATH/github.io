export default definePageConfig({
  navigationBarTitleText: '问卷管理',
  enableShareAppMessage: true,
  enableShareTimeline: true,
})
