export default definePageConfig({
  navigationBarTitleText: '问卷编辑',
  enableShareAppMessage: true,
  enableShareTimeline: true,
})
