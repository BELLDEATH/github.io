// @title 问卷编辑
import {useState, useCallback, useEffect, useMemo} from 'react'
import Taro, {useDidShow} from '@tarojs/taro'
import {useAuth} from '@/contexts/AuthContext'
import {
  getSurveyCycles,
  updateSurveyCycleName,
  getDimensions,
  addDimension,
  deleteDimension,
  getEvaluatees,
  addEvaluatee,
  deleteEvaluatee,
  getDepartments,
} from '@/db/api'
import type {SurveyCycle, Dimension, Evaluatee, Department} from '@/db/types'

export default function AdminSurveyEdit() {
  const {profile, loading} = useAuth()
  const cycleId = useMemo(() => {
    const params = Taro.getCurrentInstance().router?.params
    return decodeURIComponent(params?.id || '')
  }, [])

  const [cycle, setCycle] = useState<SurveyCycle | null>(null)
  const [cycleName, setCycleName] = useState('')
  const [editingName, setEditingName] = useState(false)
  const [dimensions, setDimensions] = useState<Dimension[]>([])
  const [evaluatees, setEvaluatees] = useState<Evaluatee[]>([])
  const [departments, setDepartments] = useState<Department[]>([])
  const [tab, setTab] = useState<'evaluatee' | 'dimension'>('evaluatee')
  const [newDimName, setNewDimName] = useState('')
  const [newEvName, setNewEvName] = useState('')
  const [newEvIdentity, setNewEvIdentity] = useState<'department_leader' | 'section_chief' | 'deputy_section_chief' | 'staff'>('staff')
  const [dataLoading, setDataLoading] = useState(true)

  const isAdmin = profile?.role === 'admin' || profile?.role === 'super_admin'

  const loadData = useCallback(async () => {
    if (!cycleId) return
    setDataLoading(true)
    try {
      const [allCycles, dims, evals, depts] = await Promise.all([
        getSurveyCycles(),
        getDimensions(),
        getEvaluatees(cycleId),
        getDepartments(),
      ])
      const found = allCycles.find((c) => c.id === cycleId)
      if (found) {
        setCycle(found)
        setCycleName(found.name)
      }
      setDimensions(dims)
      setEvaluatees(evals)
      setDepartments(depts)
    } catch (e) {
      console.error(e)
    }
    setDataLoading(false)
  }, [cycleId])

  useEffect(() => {
    loadData()
  }, [loadData])

  useDidShow(() => {
    loadData()
  })

  const handleSaveName = async () => {
    if (!cycleName.trim()) {
      Taro.showToast({title: '名称不能为空', icon: 'none'})
      return
    }
    try {
      await updateSurveyCycleName(cycleId, cycleName.trim())
      setEditingName(false)
      Taro.showToast({title: '保存成功', icon: 'success'})
      loadData()
    } catch (e: any) {
      Taro.showToast({title: e.message || '保存失败', icon: 'none'})
    }
  }

  const handleAddDimension = async () => {
    if (!newDimName.trim()) {
      Taro.showToast({title: '请输入维度名称', icon: 'none'})
      return
    }
    try {
      await addDimension(newDimName.trim())
      setNewDimName('')
      Taro.showToast({title: '添加成功', icon: 'success'})
      loadData()
    } catch (e: any) {
      Taro.showToast({title: e.message || '添加失败', icon: 'none'})
    }
  }

  const handleDeleteDimension = (id: string) => {
    Taro.showModal({
      title: '确认删除',
      content: '删除后相关评分数据将丢失，是否继续？',
      success: async (res) => {
        if (res.confirm) {
          try {
            await deleteDimension(id)
            Taro.showToast({title: '已删除', icon: 'success'})
            loadData()
          } catch (e: any) {
            Taro.showToast({title: e.message || '删除失败', icon: 'none'})
          }
        }
      },
    })
  }

  const handleAddEvaluatee = async () => {
    if (!newEvName.trim()) {
      Taro.showToast({title: '请输入姓名', icon: 'none'})
      return
    }
    try {
      await addEvaluatee({
        name: newEvName.trim(),
        department: null,
        identity: newEvIdentity,
        cycle_id: cycleId,
      })
      setNewEvName('')
      Taro.showToast({title: '添加成功', icon: 'success'})
      loadData()
    } catch (e: any) {
      Taro.showToast({title: e.message || '添加失败', icon: 'none'})
    }
  }

  const handleDeleteEvaluatee = (id: string) => {
    Taro.showModal({
      title: '确认删除',
      content: '确认从此问卷移除该被评价人？',
      success: async (res) => {
        if (res.confirm) {
          try {
            await deleteEvaluatee(id)
            Taro.showToast({title: '已删除', icon: 'success'})
            loadData()
          } catch (e: any) {
            Taro.showToast({title: e.message || '删除失败', icon: 'none'})
          }
        }
      },
    })
  }

  if (loading || dataLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="i-mdi-loading text-4xl text-primary animate-spin" />
      </div>
    )
  }

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center px-6">
        <div className="i-mdi-lock-outline text-6xl text-muted-foreground mb-4" />
        <span className="text-xl text-muted-foreground">无权限访问</span>
      </div>
    )
  }

  if (!cycle) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center px-6">
        <div className="i-mdi-alert-circle-outline text-6xl text-muted-foreground mb-4" />
        <span className="text-xl text-muted-foreground">未找到问卷</span>
      </div>
    )
  }

  const statusLabel = cycle.status === 'active' ? '进行中' : cycle.status === 'draft' ? '未开始' : '已结束'
  const statusColor = cycle.status === 'active' ? 'text-success' : cycle.status === 'draft' ? 'text-accent' : 'text-muted-foreground'

  return (
    <div className="min-h-screen bg-background pb-8">
      {/* 顶部 */}
      <div className="bg-gradient-primary px-6 pt-8 pb-10 rounded-b-3xl">
        <div className="flex items-center gap-3">
          <div
            onClick={() => Taro.navigateBack()}
            className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
            <div className="i-mdi-arrow-left text-2xl text-white" />
          </div>
          <div className="flex flex-col flex-1">
            <span className="text-2xl font-bold text-white">问卷编辑</span>
            <span className="text-xl text-white/80">{cycle.name}</span>
          </div>
        </div>
      </div>

      {/* 问卷基本信息 */}
      <div className="px-4 -mt-4 mb-4">
        <div className="bg-card rounded-2xl shadow-card p-4">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xl font-bold text-foreground">基本信息</span>
            <span className={`text-xl font-semibold ${statusColor}`}>{statusLabel}</span>
          </div>
          {editingName ? (
            <div className="flex flex-col gap-3">
              <div className="border-2 border-primary rounded-xl px-4 py-3 bg-background overflow-hidden">
                <input
                  className="w-full text-xl text-foreground bg-transparent outline-none"
                  placeholder="请输入问卷名称"
                  value={cycleName}
                  onInput={(e) => {
                    const ev = e as any
                    setCycleName(ev.detail?.value ?? ev.target?.value ?? '')
                  }}
                />
              </div>
              <div className="flex flex-row gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setCycleName(cycle.name)
                    setEditingName(false)
                  }}
                  className="flex-1 flex items-center justify-center leading-none break-keep rounded-xl bg-muted">
                  <div className="py-3 px-4">
                    <span className="text-xl text-muted-foreground">取消</span>
                  </div>
                </button>
                <button
                  type="button"
                  onClick={handleSaveName}
                  className="flex-1 flex items-center justify-center leading-none break-keep rounded-xl bg-primary">
                  <div className="py-3 px-4">
                    <span className="text-xl text-primary-foreground font-semibold">保存</span>
                  </div>
                </button>
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-between">
              <span className="text-xl text-foreground flex-1">{cycle.name}</span>
              <button
                type="button"
                onClick={() => setEditingName(true)}
                className="flex items-center justify-center leading-none break-keep rounded-lg bg-primary/10">
                <div className="py-2 px-3 flex items-center gap-1">
                  <div className="i-mdi-pencil text-xl text-primary" />
                  <span className="text-xl text-primary">改名</span>
                </div>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Tab切换 */}
      <div className="px-4 mb-4">
        <div className="bg-card rounded-2xl shadow-card overflow-hidden">
          <div className="flex flex-row">
            <div
              onClick={() => setTab('evaluatee')}
              className={`flex-1 flex items-center justify-center py-3 ${tab === 'evaluatee' ? 'border-b-2 border-primary' : ''}`}>
              <span className={`text-xl ${tab === 'evaluatee' ? 'text-primary font-bold' : 'text-muted-foreground'}`}>
                被评价人 ({evaluatees.length})
              </span>
            </div>
            <div
              onClick={() => setTab('dimension')}
              className={`flex-1 flex items-center justify-center py-3 ${tab === 'dimension' ? 'border-b-2 border-primary' : ''}`}>
              <span className={`text-xl ${tab === 'dimension' ? 'text-primary font-bold' : 'text-muted-foreground'}`}>
                评价维度 ({dimensions.length})
              </span>
            </div>
          </div>
        </div>
      </div>

      <div className="px-4">
        {tab === 'evaluatee' && (
          <div className="flex flex-col gap-4">
            {/* 添加被评价人 */}
            <div className="bg-card rounded-2xl shadow-card p-4">
              <span className="text-xl font-bold text-foreground mb-3">添加被评价人</span>
              <div className="border-2 border-input rounded-xl px-4 py-3 bg-background overflow-hidden mb-3">
                <input
                  className="w-full text-xl text-foreground bg-transparent outline-none"
                  placeholder="姓名"
                  value={newEvName}
                  onInput={(e) => {
                    const ev = e as any
                    setNewEvName(ev.detail?.value ?? ev.target?.value ?? '')
                  }}
                />
              </div>
              <div className="flex flex-row gap-2 mb-3">
                <div className="flex flex-row bg-muted rounded-xl overflow-hidden flex-1">
                  {([
                    {value: 'staff', label: '科员'},
                    {value: 'deputy_section_chief', label: '副科长'},
                    {value: 'section_chief', label: '科长'},
                    {value: 'department_leader', label: '部领导'},
                  ] as const).map((opt) => (
                    <div
                      key={opt.value}
                      onClick={() => setNewEvIdentity(opt.value)}
                      className={`flex-1 px-2 py-2 flex items-center justify-center ${newEvIdentity === opt.value ? 'bg-primary' : ''}`}>
                      <span className={`text-xl ${newEvIdentity === opt.value ? 'text-white' : 'text-muted-foreground'}`}>
                        {opt.label}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
              <button
                type="button"
                onClick={handleAddEvaluatee}
                className="w-full flex items-center justify-center leading-none break-keep rounded-xl bg-primary">
                <div className="py-3 px-6 flex items-center gap-2">
                  <div className="i-mdi-plus text-2xl text-white" />
                  <span className="text-xl text-primary-foreground font-semibold">添加</span>
                </div>
              </button>
            </div>

            {/* 被评价人列表 */}
            <div className="bg-card rounded-2xl shadow-card overflow-hidden">
              {evaluatees.length === 0 ? (
                <div className="flex flex-col items-center py-8">
                  <div className="i-mdi-account-group-outline text-4xl text-muted-foreground mb-2" />
                  <span className="text-xl text-muted-foreground">暂无被评价人</span>
                </div>
              ) : (
                evaluatees.map((ev, idx) => (
                  <div
                    key={ev.id}
                    className={`flex items-center justify-between px-5 py-4 ${
                      idx < evaluatees.length - 1 ? 'border-b border-border' : ''
                    }`}>
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                        <span className="text-xl text-primary font-bold">{idx + 1}</span>
                      </div>
                      <div className="flex flex-col">
                        <span className="text-xl font-bold text-foreground">{ev.name}</span>
                        <span className="text-xl text-muted-foreground">
                          {{department_leader: '部领导', section_chief: '科长', deputy_section_chief: '副科长', staff: '科员'}[ev.identity] || ev.identity}
                        </span>
                      </div>
                    </div>
                    <div onClick={() => handleDeleteEvaluatee(ev.id)}>
                      <div className="i-mdi-delete-outline text-2xl text-destructive" />
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {tab === 'dimension' && (
          <div className="flex flex-col gap-4">
            <div className="bg-muted/50 rounded-xl px-4 py-3">
              <div className="flex items-center gap-2">
                <div className="i-mdi-information-outline text-xl text-accent" />
                <span className="text-xl text-muted-foreground">评价维度为全局配置，修改影响所有问卷</span>
              </div>
            </div>

            {/* 添加维度 */}
            <div className="bg-card rounded-2xl shadow-card p-4">
              <span className="text-xl font-bold text-foreground mb-3">添加评价维度</span>
              <div className="flex flex-row gap-2">
                <div className="flex-1 border-2 border-input rounded-xl px-4 py-3 bg-background overflow-hidden">
                  <input
                    className="w-full text-xl text-foreground bg-transparent outline-none"
                    placeholder="维度名称"
                    value={newDimName}
                    onInput={(e) => {
                      const ev = e as any
                      setNewDimName(ev.detail?.value ?? ev.target?.value ?? '')
                    }}
                  />
                </div>
                <button
                  type="button"
                  onClick={handleAddDimension}
                  className="flex items-center justify-center leading-none break-keep rounded-xl bg-primary">
                  <div className="py-3 px-4">
                    <div className="i-mdi-plus text-2xl text-white" />
                  </div>
                </button>
              </div>
            </div>

            {/* 维度列表 */}
            <div className="bg-card rounded-2xl shadow-card overflow-hidden">
              {dimensions.map((dim, idx) => (
                <div
                  key={dim.id}
                  className={`flex items-center justify-between px-5 py-4 ${
                    idx < dimensions.length - 1 ? 'border-b border-border' : ''
                  }`}>
                  <div className="flex items-center gap-2">
                    <span className="text-xl text-muted-foreground">{idx + 1}.</span>
                    <span className="text-xl font-bold text-foreground">{dim.name}</span>
                  </div>
                  <div onClick={() => handleDeleteDimension(dim.id)}>
                    <div className="i-mdi-delete-outline text-2xl text-destructive" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
