export default definePageConfig({
  navigationBarTitleText: '身份认证',
  enableShareAppMessage: true,
  enableShareTimeline: true,
})
