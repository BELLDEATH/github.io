// @title 身份认证
import {useState, useCallback, useEffect} from 'react'
import Taro from '@tarojs/taro'
import {Picker} from '@tarojs/components'
import {useAuth} from '@/contexts/AuthContext'
import {getDepartments, getActiveCycle, getMySubmission} from '@/db/api'
import type {IdentityType} from '@/db/types'

const IDENTITY_OPTIONS: {value: IdentityType; label: string; icon: string; desc: string}[] = [
  {value: 'department_leader', label: '部领导', icon: 'i-mdi-crown-outline', desc: '部门主要领导'},
  {value: 'section_chief', label: '科长', icon: 'i-mdi-account-tie', desc: '科室负责人'},
  {value: 'deputy_section_chief', label: '副科长', icon: 'i-mdi-account-supervisor', desc: '科室副职'},
  {value: 'staff', label: '科员', icon: 'i-mdi-account-outline', desc: '科室成员'},
]

export default function Identity() {
  const {user} = useAuth()
  const [identity, setIdentity] = useState<IdentityType | ''>('')
  const [department, setDepartment] = useState('')
  const [departments, setDepartments] = useState<string[]>([])
  const [deptIndex, setDeptIndex] = useState(0)

  const loadData = useCallback(async () => {
    try {
      const depts = await getDepartments()
      const names = depts.map((d) => d.name)
      setDepartments(names)
      if (names.length > 0) {
        setDepartment(names[0])
      }
    } catch (e) {
      console.error('加载科室失败:', e)
    }
  }, [])

  useEffect(() => {
    loadData()
  }, [loadData])

  const handleSubmit = async () => {
    if (!identity) {
      Taro.showToast({title: '请选择身份', icon: 'none'})
      return
    }
    if (!department) {
      Taro.showToast({title: '请选择科室', icon: 'none'})
      return
    }
    if (!user) return

    try {
      const cycle = await getActiveCycle()
      if (!cycle) {
        Taro.showToast({title: '无进行中的问卷', icon: 'none'})
        return
      }
      const sub = await getMySubmission(cycle.id, user.id)
      if (sub) {
        Taro.showToast({title: '您已提交过评价', icon: 'none'})
        Taro.switchTab({url: '/pages/result/index'})
        return
      }
    } catch (e) {
      console.error(e)
    }

    Taro.setStorageSync('survey_identity', identity)
    Taro.setStorageSync('survey_department', department)
    Taro.navigateTo({url: '/pages/survey/index'})
  }

  return (
    <div className="min-h-screen bg-background px-4 py-6">
      {/* 步骤指示器 */}
      <div className="flex items-center justify-center gap-2 mb-8">
        <div className="flex items-center gap-1">
          <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center">
            <div className="i-mdi-check text-lg text-white" />
          </div>
          <span className="text-xl text-primary font-semibold">登录</span>
        </div>
        <div className="w-12 h-0.5 bg-primary" />
        <div className="flex items-center gap-1">
          <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center">
            <span className="text-lg text-white font-bold">2</span>
          </div>
          <span className="text-xl text-primary font-semibold">身份</span>
        </div>
        <div className="w-12 h-0.5 bg-border" />
        <div className="flex items-center gap-1">
          <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center">
            <span className="text-lg text-muted-foreground font-bold">3</span>
          </div>
          <span className="text-xl text-muted-foreground">打分</span>
        </div>
      </div>

      <div className="bg-card rounded-2xl shadow-card p-6">
        <div className="flex items-center gap-2 mb-6">
          <div className="i-mdi-account-question-outline text-2xl text-primary" />
          <span className="text-2xl font-bold text-foreground">身份认证</span>
        </div>
        <p className="text-xl text-muted-foreground mb-6 leading-relaxed">
          请选择您的身份和所属科室，此信息仅用于数据分组统计，不会展示给其他用户
        </p>

        {/* 身份选择 - 2×2 网格 */}
        <div className="mb-6">
          <span className="text-xl text-foreground font-semibold mb-3">您的身份</span>
          <div className="grid grid-cols-2 gap-3 mt-3" style={{display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px'}}>
            {IDENTITY_OPTIONS.map((opt) => (
              <div
                key={opt.value}
                onClick={() => setIdentity(opt.value)}
                className={`flex flex-col items-center py-4 px-3 rounded-xl border-2 transition ${
                  identity === opt.value ? 'border-primary bg-primary/5' : 'border-border bg-background'
                }`}>
                <div
                  className={`${opt.icon} text-3xl mb-2 ${
                    identity === opt.value ? 'text-primary' : 'text-muted-foreground'
                  }`}
                />
                <span className={`text-xl font-semibold ${identity === opt.value ? 'text-primary' : 'text-foreground'}`}>
                  {opt.label}
                </span>
                <span className="text-xl text-muted-foreground mt-0.5">{opt.desc}</span>
              </div>
            ))}
          </div>
        </div>

        {/* 科室选择 */}
        <div className="mb-8">
          <span className="text-xl text-foreground font-semibold mb-3">所属科室</span>
          <Picker
            mode="selector"
            range={departments}
            value={deptIndex}
            onChange={(e) => {
              const idx = Number(e.detail.value)
              setDeptIndex(idx)
              setDepartment(departments[idx])
            }}>
            <div className="border-2 border-input rounded-xl px-4 py-3 bg-background flex items-center justify-between mt-3">
              <span className="text-xl text-foreground">{department || '请选择科室'}</span>
              <div className="i-mdi-chevron-down text-2xl text-muted-foreground" />
            </div>
          </Picker>
        </div>

        <button
          type="button"
          onClick={handleSubmit}
          className="w-full flex items-center justify-center leading-none break-keep rounded-xl bg-primary">
          <div className="py-4 px-6 flex items-center gap-2">
            <span className="text-xl text-primary-foreground font-semibold">下一步</span>
            <div className="i-mdi-arrow-right text-2xl text-white" />
          </div>
        </button>
      </div>
    </div>
  )
}
