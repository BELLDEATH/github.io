// @title 登录
import {useState} from 'react'
import Taro from '@tarojs/taro'
import {useAuth} from '@/contexts/AuthContext'

export default function Login() {
  const {signInWithWechat, signInWithUsername, signUpWithUsername} = useAuth()
  const [agreed, setAgreed] = useState(false)
  const [loading, setLoading] = useState(false)
  const [mode, setMode] = useState<'wechat' | 'admin'>('wechat')
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')

  const handleWechatLogin = async () => {
    if (!agreed) {
      Taro.showToast({title: '请先同意隐私政策', icon: 'none'})
      return
    }
    setLoading(true)
    const {error} = await signInWithWechat()
    setLoading(false)
    if (error) {
      Taro.showToast({title: error.message || '登录失败', icon: 'none'})
    } else {
      Taro.switchTab({url: '/pages/home/index'})
    }
  }

  const handleAdminLogin = async () => {
    if (!agreed) {
      Taro.showToast({title: '请先同意隐私政策', icon: 'none'})
      return
    }
    if (!username || !password) {
      Taro.showToast({title: '请输入账号密码', icon: 'none'})
      return
    }
    setLoading(true)
    const {error} = await signInWithUsername(username, password)
    if (error) {
      // 尝试注册
      const {error: regError} = await signUpWithUsername(username, password)
      if (regError) {
        setLoading(false)
        Taro.showToast({title: regError.message || '登录失败', icon: 'none'})
        return
      }
      const {error: loginError2} = await signInWithUsername(username, password)
      setLoading(false)
      if (loginError2) {
        Taro.showToast({title: loginError2.message || '登录失败', icon: 'none'})
        return
      }
    } else {
      setLoading(false)
    }
    Taro.switchTab({url: '/pages/home/index'})
  }

  return (
    <div className="min-h-screen bg-gradient-subtle flex flex-col px-6">
      {/* 顶部品牌区 */}
      <div className="flex flex-col items-center pt-20 pb-10">
        <div className="w-20 h-20 rounded-2xl bg-gradient-primary flex items-center justify-center shadow-elegant mb-5">
          <div className="i-mdi-clipboard-check-outline text-4xl text-white" />
        </div>
        <h1 className="text-3xl font-bold text-foreground">员工互评系统</h1>
        <p className="text-xl text-muted-foreground mt-2">匿名打分 · 公正透明</p>
      </div>

      {/* 登录卡片 */}
      <div className="bg-card rounded-2xl shadow-card p-6">
        {/* 模式切换 */}
        <div className="flex flex-row bg-muted rounded-xl p-1 mb-6">
          <div
            onClick={() => setMode('wechat')}
            className={`flex-1 flex items-center justify-center py-3 rounded-lg transition ${
              mode === 'wechat' ? 'bg-card shadow-card' : ''
            }`}>
            <span className={`text-xl ${mode === 'wechat' ? 'text-primary font-semibold' : 'text-muted-foreground'}`}>
              微信登录
            </span>
          </div>
          <div
            onClick={() => setMode('admin')}
            className={`flex-1 flex items-center justify-center py-3 rounded-lg transition ${
              mode === 'admin' ? 'bg-card shadow-card' : ''
            }`}>
            <span className={`text-xl ${mode === 'admin' ? 'text-primary font-semibold' : 'text-muted-foreground'}`}>
              管理员登录
            </span>
          </div>
        </div>

        {mode === 'wechat' ? (
          <div className="flex flex-col gap-4">
            <p className="text-xl text-muted-foreground text-center leading-relaxed">
              本系统仅供部门内部员工使用，请使用微信账号登录
            </p>
            <button
              type="button"
              onClick={handleWechatLogin}
              className={`w-full flex items-center justify-center leading-none break-keep rounded-xl ${
                loading ? 'bg-primary/50' : 'bg-primary'
              }`}>
              <div className="py-4 px-6 flex items-center gap-2">
                <div className="i-mdi-wechat text-2xl text-white" />
                <span className="text-xl text-primary-foreground font-semibold">
                  {loading ? '登录中...' : '微信一键登录'}
                </span>
              </div>
            </button>
            <div className="flex items-center justify-center mt-2">
              <span
                className="text-xl text-muted-foreground"
                onClick={() => Taro.navigateTo({url: '/pages/admin-login/index'})}>
                管理员入口 →
              </span>
            </div>
          </div>
        ) : (
          <div className="flex flex-col gap-4">
            <div className="border-2 border-input rounded-xl px-4 py-3 bg-background overflow-hidden">
              <input
                className="w-full text-xl text-foreground bg-transparent outline-none"
                placeholder="请输入管理员账号"
                value={username}
                onInput={(e) => {
                  const ev = e as any
                  setUsername(ev.detail?.value ?? ev.target?.value ?? '')
                }}
              />
            </div>
            <div className="border-2 border-input rounded-xl px-4 py-3 bg-background overflow-hidden">
              <input
                className="w-full text-xl text-foreground bg-transparent outline-none"
                placeholder="请输入密码"
                type="password"
                value={password}
                onInput={(e) => {
                  const ev = e as any
                  setPassword(ev.detail?.value ?? ev.target?.value ?? '')
                }}
              />
            </div>
            <button
              type="button"
              onClick={handleAdminLogin}
              className={`w-full flex items-center justify-center leading-none break-keep rounded-xl ${
                loading ? 'bg-primary/50' : 'bg-primary'
              }`}>
              <div className="py-4 px-6">
                <span className="text-xl text-primary-foreground font-semibold">
                  {loading ? '登录中...' : '管理员登录'}
                </span>
              </div>
            </button>
          </div>
        )}
      </div>

      {/* 协议勾选 */}
      <div className="flex items-start gap-2 mt-6 px-2" onClick={() => setAgreed(!agreed)}>
        <div
          className={`w-6 h-6 rounded-md flex items-center justify-center mt-0.5 ${
            agreed ? 'bg-primary' : 'border-2 border-border bg-card'
          }`}>
          {agreed && <div className="i-mdi-check text-base text-white" />}
        </div>
        <div className="flex flex-wrap text-xl text-muted-foreground leading-relaxed">
          <span>我已阅读并同意</span>
          <span
            className="text-primary"
            onClick={(e) => {
              e.stopPropagation()
              Taro.navigateTo({url: '/pages/privacy/index'})
            }}>
            《隐私政策》
          </span>
          <span>与</span>
          <span
            className="text-primary"
            onClick={(e) => {
              e.stopPropagation()
              Taro.navigateTo({url: '/pages/privacy/index'})
            }}>
            《用户协议》
          </span>
        </div>
      </div>

      <p className="text-xl text-muted-foreground text-center mt-8 leading-relaxed">
        您的评价将完全匿名展示
      </p>
    </div>
  )
}