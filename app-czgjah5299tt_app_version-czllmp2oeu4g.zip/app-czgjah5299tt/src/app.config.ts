const pages = [
  'pages/home/index',
  'pages/result/index',
  'pages/profile/index',
  'pages/login/index',
  'pages/identity/index',
  'pages/survey/index',
  'pages/privacy/index',
  'pages/data-list/index',
  'pages/admin/index',
  'pages/admin-data/index',
  'pages/admin-survey/index',
  'pages/admin-users/index',
  'pages/admin-survey-edit/index',
  'pages/admin-login/index',
]

//  To fully leverage TypeScript's type safety and ensure its correctness, always enclose the configuration object within the global defineAppConfig helper function.
export default defineAppConfig({
  pages,
  tabBar: {
    color: '#64748B',
    selectedColor: '#2563EB',
    backgroundColor: '#FFFFFF',
    borderStyle: 'white',
    list: [
      {
        pagePath: 'pages/home/index',
        text: '首页',
        iconPath: './assets/icons/home_unselected.png',
        selectedIconPath: './assets/icons/home_selected.png',
      },
      {
        pagePath: 'pages/result/index',
        text: '结果',
        iconPath: './assets/icons/result_unselected.png',
        selectedIconPath: './assets/icons/result_selected.png',
      },
      {
        pagePath: 'pages/profile/index',
        text: '我的',
        iconPath: './assets/icons/profile_unselected.png',
        selectedIconPath: './assets/icons/profile_selected.png',
      },
    ],
  },
  window: {
    backgroundTextStyle: 'light',
    navigationBarBackgroundColor: '#2563EB',
    navigationBarTitleText: '员工互评',
    navigationBarTextStyle: 'white',
  },
})
