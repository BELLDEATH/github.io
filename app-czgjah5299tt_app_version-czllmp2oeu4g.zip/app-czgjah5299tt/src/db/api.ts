import {supabase} from '@/client/supabase'
import type {
  Department,
  Dimension,
  Evaluatee,
  Profile,
  Rating,
  Submission,
  SurveyCycle,
  SurveyStatus,
  IdentityType,
  UserRole,
} from './types'

// ===== 科室 =====
export async function getDepartments(): Promise<Department[]> {
  const {data, error} = await supabase
    .from('departments')
    .select('*')
    .order('sort_order', {ascending: true})
    .limit(100)
  if (error) throw error
  return Array.isArray(data) ? data : []
}

export async function addDepartment(name: string) {
  const {error} = await supabase.from('departments').insert({name})
  if (error) throw error
}

export async function deleteDepartment(id: string) {
  const {error} = await supabase.from('departments').delete().eq('id', id)
  if (error) throw error
}

// ===== 问卷周期 =====
export async function getSurveyCycles(): Promise<SurveyCycle[]> {
  const {data, error} = await supabase
    .from('survey_cycles')
    .select('*')
    .order('created_at', {ascending: false})
    .limit(100)
  if (error) throw error
  return Array.isArray(data) ? data : []
}

export async function getActiveCycle(): Promise<SurveyCycle | null> {
  const {data, error} = await supabase
    .from('survey_cycles')
    .select('*')
    .eq('status', 'active')
    .order('created_at', {ascending: false})
    .limit(1)
    .maybeSingle()
  if (error) throw error
  return data
}

export async function createSurveyCycle(name: string) {
  const {error} = await supabase.from('survey_cycles').insert({name})
  if (error) throw error
}

export async function updateSurveyCycleStatus(id: string, status: SurveyStatus) {
  const {error} = await supabase
    .from('survey_cycles')
    .update({status, updated_at: new Date().toISOString()})
    .eq('id', id)
  if (error) throw error
}

export async function deleteSurveyCycle(id: string) {
  const {error} = await supabase.from('survey_cycles').delete().eq('id', id)
  if (error) throw error
}

// ===== 评价维度 =====
export async function getDimensions(): Promise<Dimension[]> {
  const {data, error} = await supabase
    .from('dimensions')
    .select('*')
    .order('sort_order', {ascending: true})
    .limit(100)
  if (error) throw error
  return Array.isArray(data) ? data : []
}

export async function addDimension(name: string) {
  const {data: maxData} = await supabase
    .from('dimensions')
    .select('sort_order')
    .order('sort_order', {ascending: false})
    .limit(1)
  const nextOrder = maxData && maxData.length > 0 ? maxData[0].sort_order + 1 : 0
  const {error} = await supabase.from('dimensions').insert({name, sort_order: nextOrder})
  if (error) throw error
}

export async function deleteDimension(id: string) {
  const {error} = await supabase.from('dimensions').delete().eq('id', id)
  if (error) throw error
}

// ===== 被评价人 =====
export async function getEvaluatees(cycleId: string): Promise<Evaluatee[]> {
  const {data, error} = await supabase
    .from('evaluatees')
    .select('*')
    .eq('cycle_id', cycleId)
    .order('created_at', {ascending: true})
    .limit(200)
  if (error) throw error
  return Array.isArray(data) ? data : []
}

export async function addEvaluatee(evaluatee: {
  name: string
  department: string | null
  identity: IdentityType
  cycle_id: string
}) {
  const {error} = await supabase.from('evaluatees').insert(evaluatee)
  if (error) throw error
}

export async function addEvaluateesBatch(
  evaluatees: {name: string; department: string | null; identity: IdentityType; cycle_id: string}[],
) {
  const {error} = await supabase.from('evaluatees').insert(evaluatees)
  if (error) throw error
}

export async function deleteEvaluatee(id: string) {
  const {error} = await supabase.from('evaluatees').delete().eq('id', id)
  if (error) throw error
}

// ===== 提交记录 =====
export async function getMySubmission(cycleId: string, userId: string): Promise<Submission | null> {
  const {data, error} = await supabase
    .from('submissions')
    .select('*')
    .eq('cycle_id', cycleId)
    .eq('user_id', userId)
    .limit(1)
    .maybeSingle()
  if (error) throw error
  return data
}

export async function createSubmission(submission: {
  cycle_id: string
  user_id: string
  nickname: string | null
  identity: IdentityType
  department: string | null
}) {
  const {error} = await supabase.from('submissions').insert(submission)
  if (error) throw error
}

export async function getAllSubmissions(cycleId: string): Promise<Submission[]> {
  const {data, error} = await supabase
    .from('submissions')
    .select('*')
    .eq('cycle_id', cycleId)
    .order('created_at', {ascending: false})
    .limit(500)
  if (error) throw error
  return Array.isArray(data) ? data : []
}

export async function deleteSubmission(id: string) {
  const {error} = await supabase.from('submissions').delete().eq('id', id)
  if (error) throw error
}

// 删除某用户在某周期的提交记录及其所有评分（允许该用户重新填报）
export async function deleteSubmissionWithRatings(submissionId: string, userId: string, cycleId: string) {
  // 先删评分记录
  const {error: rErr} = await supabase
    .from('ratings')
    .delete()
    .eq('evaluator_id', userId)
    .eq('cycle_id', cycleId)
  if (rErr) throw rErr
  // 再删提交记录
  const {error: sErr} = await supabase.from('submissions').delete().eq('id', submissionId)
  if (sErr) throw sErr
}

// 更新问卷周期名称
export async function updateSurveyCycleName(id: string, name: string) {
  const {error} = await supabase
    .from('survey_cycles')
    .update({name, updated_at: new Date().toISOString()})
    .eq('id', id)
  if (error) throw error
}

// ===== 评分 =====
export async function getMyRatings(cycleId: string, userId: string): Promise<Rating[]> {
  const {data, error} = await supabase
    .from('ratings')
    .select('*')
    .eq('cycle_id', cycleId)
    .eq('evaluator_id', userId)
    .order('created_at', {ascending: true})
    .limit(2000)
  if (error) throw error
  return Array.isArray(data) ? data : []
}

export async function createRatings(ratings: Omit<Rating, 'id' | 'created_at'>[]) {
  const {error} = await supabase.from('ratings').insert(ratings)
  if (error) throw error
}

export async function getAllRatings(cycleId: string): Promise<Rating[]> {
  const {data, error} = await supabase
    .from('ratings')
    .select('*')
    .eq('cycle_id', cycleId)
    .order('created_at', {ascending: false})
    .limit(5000)
  if (error) throw error
  return Array.isArray(data) ? data : []
}

// ===== 用户管理 =====
export async function getAllProfiles(): Promise<Profile[]> {
  const {data, error} = await supabase
    .from('profiles')
    .select('*')
    .order('created_at', {ascending: false})
    .limit(200)
  if (error) throw error
  return Array.isArray(data) ? data : []
}

export async function updateUserRole(userId: string, role: UserRole) {
  const {error} = await supabase.from('profiles').update({role}).eq('id', userId)
  if (error) throw error
}

// ===== 管理员设置 =====
export async function getAdminSetting(key: string): Promise<string | null> {
  const {data, error} = await supabase
    .from('admin_settings')
    .select('value')
    .eq('key', key)
    .limit(1)
    .maybeSingle()
  if (error) throw error
  return data?.value ?? null
}

export async function updateAdminSetting(key: string, value: string) {
  const {error} = await supabase
    .from('admin_settings')
    .update({value, updated_at: new Date().toISOString()})
    .eq('key', key)
  if (error) throw error
}

// ===== 统计 =====
export async function getSurveyStats(cycleId: string) {
  const [submissions, ratings, evaluatees, dimensions] = await Promise.all([
    getAllSubmissions(cycleId),
    getAllRatings(cycleId),
    getEvaluatees(cycleId),
    getDimensions(),
  ])

  const totalEvaluatees = evaluatees.length
  const totalSubmissions = submissions.length
  const completionRate = totalEvaluatees > 0 ? Math.round((totalSubmissions / totalEvaluatees) * 100) : 0

  // 各维度平均分
  const dimensionStats = dimensions.map((dim) => {
    const dimRatings = ratings.filter((r) => r.dimension_id === dim.id)
    const avg =
      dimRatings.length > 0
        ? Math.round((dimRatings.reduce((s, r) => s + r.score, 0) / dimRatings.length) * 10) / 10
        : 0
    return {dimension: dim.name, avg, count: dimRatings.length}
  })

  // 各科室对比
  const deptMap: Record<string, {count: number; total: number}> = {}
  for (const sub of submissions) {
    const dept = sub.department || '未分类'
    if (!deptMap[dept]) deptMap[dept] = {count: 0, total: 0}
    deptMap[dept].count += 1
  }
  for (const r of ratings) {
    const sub = submissions.find((s) => s.user_id === r.evaluator_id)
    const dept = sub?.department || '未分类'
    if (deptMap[dept]) deptMap[dept].total += r.score
  }
  const departmentStats = Object.entries(deptMap).map(([dept, d]) => ({
    department: dept,
    count: d.count,
    avg: d.count > 0 ? Math.round((d.total / d.count) * 10) / 10 : 0,
  }))

  // 各身份对比
  const identityMap: Record<string, {count: number; total: number}> = {leader: {count: 0, total: 0}, employee: {count: 0, total: 0}}
  for (const sub of submissions) {
    const id = sub.identity
    if (!identityMap[id]) identityMap[id] = {count: 0, total: 0}
    identityMap[id].count += 1
  }
  for (const r of ratings) {
    const sub = submissions.find((s) => s.user_id === r.evaluator_id)
    const id = sub?.identity || 'employee'
    if (identityMap[id]) identityMap[id].total += r.score
  }
  const identityStats = Object.entries(identityMap).map(([id, d]) => ({
    identity: id === 'leader' ? '领导' : '员工',
    count: d.count,
    avg: d.count > 0 ? Math.round((d.total / d.count) * 10) / 10 : 0,
  }))

  return {
    totalEvaluatees,
    totalSubmissions,
    completionRate,
    dimensionStats,
    departmentStats,
    identityStats,
  }
}