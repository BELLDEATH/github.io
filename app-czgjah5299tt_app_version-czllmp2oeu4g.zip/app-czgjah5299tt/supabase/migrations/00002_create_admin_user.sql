DO $$
DECLARE
  admin_id uuid;
BEGIN
  -- 检查是否已存在
  SELECT id INTO admin_id FROM auth.users WHERE email = 'admin@miaoda.com';
  
  IF admin_id IS NULL THEN
    admin_id := gen_random_uuid();
    INSERT INTO auth.users (
      id, instance_id, aud, role, email,
      encrypted_password, email_confirmed_at,
      raw_app_meta_data, raw_user_meta_data,
      created_at, updated_at,
      confirmation_token, email_change,
      email_change_token_new, recovery_token
    ) VALUES (
      admin_id,
      '00000000-0000-0000-0000-000000000000',
      'authenticated', 'authenticated',
      'admin@miaoda.com',
      crypt('Admin@2026', gen_salt('bf')),
      now(),
      '{"provider":"email","providers":["email"]}',
      '{"username":"admin"}',
      now(), now(), '', '', '', ''
    );
  END IF;

  -- 更新 profile 为 super_admin（触发器可能已创建 profile）
  INSERT INTO public.profiles (id, nickname, role)
  VALUES (admin_id, '超级管理员', 'super_admin')
  ON CONFLICT (id) DO UPDATE SET role = 'super_admin', nickname = '超级管理员';
END $$;