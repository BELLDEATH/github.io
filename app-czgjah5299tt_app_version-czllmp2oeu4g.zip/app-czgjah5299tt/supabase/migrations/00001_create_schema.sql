-- 用户角色枚举
CREATE TYPE public.user_role AS ENUM ('user', 'admin', 'super_admin');
-- 身份枚举
CREATE TYPE public.identity_type AS ENUM ('leader', 'employee');
-- 问卷状态枚举
CREATE TYPE public.survey_status AS ENUM ('draft', 'active', 'closed');

-- 用户档案表
CREATE TABLE public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  nickname text,
  openid text,
  role public.user_role NOT NULL DEFAULT 'user',
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- 科室表
CREATE TABLE public.departments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  sort_order bigint NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.departments ENABLE ROW LEVEL SECURITY;

-- 问卷周期表
CREATE TABLE public.survey_cycles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  status public.survey_status NOT NULL DEFAULT 'draft',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.survey_cycles ENABLE ROW LEVEL SECURITY;

-- 评价维度表
CREATE TABLE public.dimensions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  sort_order bigint NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.dimensions ENABLE ROW LEVEL SECURITY;

-- 被评价人表
CREATE TABLE public.evaluatees (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  department text,
  identity public.identity_type NOT NULL DEFAULT 'employee',
  cycle_id uuid REFERENCES public.survey_cycles(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.evaluatees ENABLE ROW LEVEL SECURITY;

-- 提交记录表
CREATE TABLE public.submissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  cycle_id uuid NOT NULL REFERENCES public.survey_cycles(id) ON DELETE CASCADE,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES public.profiles(id) ON DELETE CASCADE,
  nickname text,
  identity public.identity_type NOT NULL,
  department text,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(cycle_id, user_id)
);
ALTER TABLE public.submissions ENABLE ROW LEVEL SECURITY;

-- 评分记录表
CREATE TABLE public.ratings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  cycle_id uuid NOT NULL REFERENCES public.survey_cycles(id) ON DELETE CASCADE,
  evaluator_id uuid NOT NULL DEFAULT auth.uid() REFERENCES public.profiles(id) ON DELETE CASCADE,
  evaluatee_id uuid NOT NULL REFERENCES public.evaluatees(id) ON DELETE CASCADE,
  dimension_id uuid NOT NULL REFERENCES public.dimensions(id) ON DELETE CASCADE,
  score integer NOT NULL CHECK (score >= 1 AND score <= 10),
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.ratings ENABLE ROW LEVEL SECURITY;

-- 管理员二次验证密码表
CREATE TABLE public.admin_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key text NOT NULL UNIQUE,
  value text NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.admin_settings ENABLE ROW LEVEL SECURITY;

-- 插入默认管理员设置
INSERT INTO public.admin_settings (key, value) VALUES ('secondary_password', 'admin2026');

-- 新用户自动同步到 profiles
CREATE FUNCTION handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, nickname, openid, role)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'nickname', NEW.raw_user_meta_data->>'username', '匿名用户'),
    (NEW.raw_user_meta_data->>'openid')::text,
    'user'::public.user_role
  );
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION handle_new_user();

-- 角色查询辅助函数
CREATE OR REPLACE FUNCTION get_user_role(uid uuid)
RETURNS user_role
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT role FROM profiles WHERE id = uid;
$$;

-- profiles RLS
CREATE POLICY "Admins have full access to profiles" ON profiles
  FOR ALL TO authenticated USING (get_user_role(auth.uid()) IN ('admin'::user_role, 'super_admin'::user_role));
CREATE POLICY "Users can view their own profile" ON profiles
  FOR SELECT TO authenticated USING (auth.uid() = id);
CREATE POLICY "Users can update their own profile" ON profiles
  FOR UPDATE TO authenticated USING (auth.uid() = id)
  WITH CHECK (role IS NOT DISTINCT FROM get_user_role(auth.uid()));

-- departments RLS
CREATE POLICY "Anyone authenticated can read departments" ON departments
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "Admins can manage departments" ON departments
  FOR ALL TO authenticated USING (get_user_role(auth.uid()) IN ('admin'::user_role, 'super_admin'::user_role));

-- survey_cycles RLS
CREATE POLICY "Anyone authenticated can read active cycles" ON survey_cycles
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "Admins can manage survey cycles" ON survey_cycles
  FOR ALL TO authenticated USING (get_user_role(auth.uid()) IN ('admin'::user_role, 'super_admin'::user_role));

-- dimensions RLS
CREATE POLICY "Anyone authenticated can read dimensions" ON dimensions
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "Admins can manage dimensions" ON dimensions
  FOR ALL TO authenticated USING (get_user_role(auth.uid()) IN ('admin'::user_role, 'super_admin'::user_role));

-- evaluatees RLS
CREATE POLICY "Anyone authenticated can read evaluatees" ON evaluatees
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "Admins can manage evaluatees" ON evaluatees
  FOR ALL TO authenticated USING (get_user_role(auth.uid()) IN ('admin'::user_role, 'super_admin'::user_role));

-- submissions RLS
CREATE POLICY "Users can read own submissions" ON submissions
  FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own submissions" ON submissions
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Admins can read all submissions" ON submissions
  FOR SELECT TO authenticated USING (get_user_role(auth.uid()) IN ('admin'::user_role, 'super_admin'::user_role));
CREATE POLICY "Admins can manage submissions" ON submissions
  FOR ALL TO authenticated USING (get_user_role(auth.uid()) IN ('admin'::user_role, 'super_admin'::user_role));

-- ratings RLS
CREATE POLICY "Users can read own ratings" ON ratings
  FOR SELECT TO authenticated USING (auth.uid() = evaluator_id);
CREATE POLICY "Users can insert own ratings" ON ratings
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = evaluator_id);
CREATE POLICY "Admins can read all ratings" ON ratings
  FOR SELECT TO authenticated USING (get_user_role(auth.uid()) IN ('admin'::user_role, 'super_admin'::user_role));
CREATE POLICY "Admins can manage ratings" ON ratings
  FOR ALL TO authenticated USING (get_user_role(auth.uid()) IN ('admin'::user_role, 'super_admin'::user_role));

-- admin_settings RLS
CREATE POLICY "Admins can read settings" ON admin_settings
  FOR SELECT TO authenticated USING (get_user_role(auth.uid()) IN ('admin'::user_role, 'super_admin'::user_role));
CREATE POLICY "Admins can manage settings" ON admin_settings
  FOR ALL TO authenticated USING (get_user_role(auth.uid()) IN ('admin'::user_role, 'super_admin'::user_role));

-- 插入默认科室
INSERT INTO public.departments (name, sort_order) VALUES
  ('综合管理科', 1),
  ('技术研发科', 2),
  ('市场营销科', 3),
  ('财务审计科', 4),
  ('人力资源科', 5);

-- 插入默认评价维度
INSERT INTO public.dimensions (name, sort_order) VALUES
  ('工作态度', 1),
  ('协作能力', 2),
  ('专业能力', 3),
  ('沟通表达', 4),
  ('创新意识', 5),
  ('责任心', 6);