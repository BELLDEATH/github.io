-- 1. 添加新的 identity_type 枚举值（ALTER TYPE ADD VALUE 不可在事务中，需分步）
ALTER TYPE identity_type ADD VALUE IF NOT EXISTS 'department_leader';
ALTER TYPE identity_type ADD VALUE IF NOT EXISTS 'section_chief';
ALTER TYPE identity_type ADD VALUE IF NOT EXISTS 'deputy_section_chief';
ALTER TYPE identity_type ADD VALUE IF NOT EXISTS 'staff';

-- 2. 给 dimensions 表添加 leader_only 列
ALTER TABLE dimensions ADD COLUMN IF NOT EXISTS leader_only BOOLEAN NOT NULL DEFAULT FALSE;