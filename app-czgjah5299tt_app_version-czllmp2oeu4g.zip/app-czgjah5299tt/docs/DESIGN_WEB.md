## Vibe
- Swiss Modernism 2.0 × Institutional Official — 严格网格系统、政务蓝色权威感、无装饰排版层级

## Color
- Primary: #334155
- On Primary: #FFFFFF
- Accent: #0891B2
- On Accent: #FFFFFF
- Background: #FFFFFF
- Foreground: #0F172A
- Muted: #F1F5F9
- Border: #E2E8F0
- Secondary: #475569

## Typography
- Heading: AlibabaSansTC (family: AlibabaSansTC, weight: SemiBold, url: https://resource-static.bj.bcebos.com/fonts-skill/AlibabaSansTC_SemiBold.ttf)
- Body: AlibabaSansTC (family: AlibabaSansTC, weight: Regular, url: https://resource-static.bj.bcebos.com/fonts-skill/AlibabaSansTC_Regular.ttf)

## Visual Language
- 核心视觉签名：严格对齐的水平分割线 + 左侧 4px Primary 色竖条作为区块锚点（来自 Swiss grid baseline 系统）
- 材质与深度：无阴影或极淡 box-shadow（0 1px 3px rgba(0,0,0,0.06)）；Muted 背景区与白色卡片通过 Border 分割
- 容器与按钮：卡片纯白底 + Border 细线；主操作按钮 Primary 填充；次操作 Muted 底 + Foreground 字；输入框 Border 描边，聚焦态 Accent 色
- 布局节奏：顶栏 Primary 色 48px 高；页面内容最大宽 520px 居中；区块间用 1px Border 线分割，留白宽松

## Animation
- 交互：Tab 切换 200ms ease-out 滑动下划线；按钮 100ms scale(0.97) 按压反馈
- 进度：进度条 300ms ease 填充

## Forbidden
- 禁高饱和大色块铺底（Primary/Accent 禁做页面背景）
- 禁渐变背景、毛玻璃、大投影等通用装饰
- 禁 Emoji 图标替代功能图标

## Additional Notes
- 所有用户可见文案使用中文
- 登录页：全幅浅色背景（Muted）+ 居中卡片（白底 + Border），顶部品牌色条形标志
- 移动端优先（max-width: 520px），使用 rem 单位，基准 16px
- 管理后台在平板/桌面端展示侧边导航，移动端折叠为顶部 Tab
