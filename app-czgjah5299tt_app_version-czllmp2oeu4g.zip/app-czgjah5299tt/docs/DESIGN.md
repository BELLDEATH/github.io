## Vibe
- Clinical Clean Mobile：纯白/极浅灰背景 + 临床蓝主操作色，信息密度服务于功能，零装饰干扰

## Color
- Primary: #2563EB（临床蓝，用于 CTA、激活态、进度指示）
- On Primary: #FFFFFF
- Accent: #0891B2（青色，用于次级强调、统计数字）
- On Accent: #FFFFFF
- Background: #F8FAFC（极浅蓝灰）
- Foreground: #0F172A（近黑）
- Muted: #F1F5F9
- Muted Foreground: #64748B
- Border: #E2E8F0
- Destructive: #DC2626
- Success: #16A34A

## Typography
- Heading: vivo Sans Bold（family: vivoSans, weight: Bold, url: https://resource-static.bj.bcebos.com/fonts-skill/vivoSans_Bold.ttf）
- Body: vivo Sans Regular（family: vivoSans, weight: Regular, url: https://resource-static.bj.bcebos.com/fonts-skill/vivoSans_Regular.ttf）

## Visual Language
- 核心视觉签名：分步进度指示器（顶部步骤条 + 当前步骤高亮），贯穿问卷填写全流程
- 材质与深度：极弱阴影（shadow-sm）区分卡片层级，避免重边框；输入区域用浅灰底色聚焦
- 容器与按钮：卡片圆角 rounded-xl，主按钮实心蓝色填充，次按钮浅灰底+深色字
- 布局节奏：单列居中、宽松间距，提交按钮为唯一主强调色，非交互区域主动降对比

## Animation
- 入场：步骤切换淡入（150ms）
- 交互：按钮按压 scale 0.97 即时反馈
- 进度：进度条填充过渡（300ms ease-out）

## Forbidden
- 禁大块纯色铺底（Hero/Banner/操作区），Primary/Accent 仅小面积焦点
- 禁 Emoji 图标，使用 MDI 图标
- 禁高饱和背景、复杂插画与输入区域竞争

## Additional Notes
- 所有用户可见文案为中文
- 矩阵量表打分页：行=评价维度，列=被评价人，每格 1-10 分下拉选择
- 前台完全匿名，后台管理员可见昵称